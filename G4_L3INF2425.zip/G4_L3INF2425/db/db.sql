CREATE DATABASE IF NOT EXISTS reservation_cite_universitaire;
USE reservation_cite_universitaire;

-- 1. Table Batiment
CREATE TABLE batiment (
    id_bat INT AUTO_INCREMENT PRIMARY KEY,
    nbre_ch INT NOT NULL,
    section ENUM('fille', 'garçon') NOT NULL,
    statut ENUM('étudiant', 'enseignant') NOT NULL
);

-- 2. Table Chambre
CREATE TABLE chambre (
    numero INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('studio', 'simple') NOT NULL,
    disponibilite ENUM('oui', 'non') DEFAULT 'oui',
    prix DECIMAL(10, 2) NOT NULL,
    id_bat INT,
    FOREIGN KEY (id_bat) REFERENCES batiment(id_bat) ON DELETE CASCADE
);

-- 3. Table Equipement
CREATE TABLE equipement (
    id_equi INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    image VARCHAR(255),
    numero_chambre INT,
    FOREIGN KEY (numero_chambre) REFERENCES chambre(numero) ON DELETE CASCADE
);

-- 4. Table Etudiant
CREATE TABLE etudiant (
    matricule VARCHAR(20) PRIMARY KEY,
    nom VARCHAR(100),
    prenom VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    tel VARCHAR(20),
    photo VARCHAR(255),
    tel_parent VARCHAR(20),
    adress_parent TEXT,
    sexe ENUM('Homme', 'Femme'),
    faculte VARCHAR(100),
    password VARCHAR(255) -- mot de passe hashé
);

-- 5. Table Commentaire
CREATE TABLE commentaire (
    id_com INT AUTO_INCREMENT PRIMARY KEY,
    message TEXT NOT NULL,
    date_envoie DATETIME,
    id_equi INT,
    matricule_etudiant VARCHAR(20),
    FOREIGN KEY (id_equi) REFERENCES equipement(id_equi) ON DELETE CASCADE,
    FOREIGN KEY (matricule_etudiant) REFERENCES etudiant(matricule) ON DELETE CASCADE
);

-- Trigger : ajout automatique de la date_envoie
DELIMITER $$
CREATE TRIGGER before_insert_commentaire
BEFORE INSERT ON commentaire
FOR EACH ROW
BEGIN
    SET NEW.date_envoie = NOW();
END$$
DELIMITER ;

-- 6. Table Reservation
CREATE TABLE reservation (
    id_reser INT AUTO_INCREMENT PRIMARY KEY,
    date_reservation DATETIME DEFAULT CURRENT_TIMESTAMP,
    type_payement ENUM('Espèce', 'Carte', 'Mobile Money') NOT NULL,
    matricule_etudiant VARCHAR(20),
    numero_chambre INT,
    FOREIGN KEY (matricule_etudiant) REFERENCES etudiant(matricule) ON DELETE CASCADE,
    FOREIGN KEY (numero_chambre) REFERENCES chambre(numero) ON DELETE CASCADE
);

-- Trigger pour mettre à jour automatiquement la disponibilité d'une chambre lors d'une réservation
DELIMITER $$
CREATE TRIGGER after_insert_reservation
AFTER INSERT ON reservation
FOR EACH ROW
BEGIN
    UPDATE chambre SET disponibilite = 'non' WHERE numero = NEW.numero_chambre;
END$$
DELIMITER ;

-- Trigger pour remettre une chambre en disponibilité lors de l'annulation d'une réservation
DELIMITER $$
CREATE TRIGGER after_delete_reservation
AFTER DELETE ON reservation
FOR EACH ROW
BEGIN
    UPDATE chambre SET disponibilite = 'oui' WHERE numero = OLD.numero_chambre;
END$$
DELIMITER ;

-- Trigger pour empêcher la réservation si l'étudiant a déjà une réservation active
DELIMITER $$
CREATE TRIGGER before_insert_reservation
BEFORE INSERT ON reservation
FOR EACH ROW
BEGIN
    DECLARE existing_reservations INT;
    
    SELECT COUNT(*) INTO existing_reservations 
    FROM reservation 
    WHERE matricule_etudiant = NEW.matricule_etudiant;
    
    IF existing_reservations > 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Cet étudiant a déjà une réservation active';
    END IF;
END$$
DELIMITER ;