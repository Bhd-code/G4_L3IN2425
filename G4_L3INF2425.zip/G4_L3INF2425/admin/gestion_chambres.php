<?php
session_start();

try {
    $db = new PDO('mysql:host=localhost;dbname=reservation_cite_universitaire;charset=utf8', 'root', '');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

$errors = [];
$success = '';

// Suppression directe
if (isset($_GET['supprimer'])) {
    $id = (int) $_GET['supprimer'];
    if ($id > 0) {
        try {
            $stmt = $db->prepare("DELETE FROM chambre WHERE numero = ?");
            $stmt->execute([$id]);
            $success = "Chambre supprimée avec succès.";
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la suppression : " . $e->getMessage();
        }
    } else {
        $errors[] = "ID invalide pour suppression.";
    }
}

// Ajout d'une chambre
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = trim($_POST['type'] ?? '');
    $disponibilite = $_POST['disponibilite'] ?? '';
    $prix = filter_input(INPUT_POST, 'prix', FILTER_VALIDATE_FLOAT);
    $id_bat = filter_input(INPUT_POST, 'id_bat', FILTER_VALIDATE_INT);
    $numero_ch = filter_input(INPUT_POST, 'numero_ch', FILTER_VALIDATE_INT);
    $image = null;

    if (empty($type)) $errors[] = "Le type de chambre est requis.";
    if (!in_array($disponibilite, ['oui', 'non'])) $errors[] = "Disponibilité invalide.";
    if ($prix === false || $prix <= 0) $errors[] = "Prix invalide.";
    if (!$id_bat || $id_bat <= 0) $errors[] = "ID du bâtiment invalide.";
    if (!$numero_ch || $numero_ch <= 0) $errors[] = "Numéro de chambre invalide.";

    // Gestion de l'image
    if (!empty($_FILES['image']['name'])) {
        $imageName = basename($_FILES['image']['name']);
        $imageTmp = $_FILES['image']['tmp_name'];
        $imageExt = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($imageExt, $allowed)) {
            $newName = uniqid("chambre_", true) . '.' . $imageExt;
            $uploadPath = __DIR__ . "/uploads/chambres/";
            if (!file_exists($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            move_uploaded_file($imageTmp, $uploadPath . $newName);
            $image = "uploads/chambres/" . $newName;
        } else {
            $errors[] = "Format d’image non autorisé (jpg, png, gif seulement).";
        }
    }

    if (empty($errors)) {
        try {
            $stmt = $db->prepare("INSERT INTO chambre (type, disponibilite, prix, id_bat, numero_ch, image) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$type, $disponibilite, $prix, $id_bat, $numero_ch, $image]);
            $success = "Chambre ajoutée avec succès.";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $errors[] = "Une chambre avec ce numéro existe déjà.";
            } else {
                $errors[] = "Erreur lors de l'ajout : " . $e->getMessage();
            }
        }
    }
}

// Récupération des chambres
$chambres = $db->query("SELECT * FROM chambre ORDER BY numero_ch DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des chambres</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../image/image2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0; padding: 0;
        }
        .overlay {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }
        .top-right {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .btn-home {
            background-color: #0d6efd;
            color: white;
            font-weight: bold;
            border-radius: 30px;
            padding: 0.5rem 1rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            text-decoration: none;
        }
        .form-card {
            background-color: rgba(255, 255, 255, 0.95);
        }
        .image-thumbnail {
            width: 80px;
            height: auto;
        }
    </style>
</head>
<body>

<div class="top-right">
    <a href="inde2.php" class="btn-home">🏠 Accueil</a>
</div>

<div class="container py-5">
    <div class="overlay">
        <h2 class="mb-4">Ajouter une chambre</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="card p-4 shadow-sm mb-5 form-card">
            <div class="mb-3">
                <label class="form-label">Type de chambre *</label>
                <input type="text" name="type" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Disponibilité *</label>
                <select name="disponibilite" class="form-select" required>
                    <option value="">Choisir...</option>
                    <option value="oui">Oui</option>
                    <option value="non">Non</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Prix *</label>
                <input type="number" step="0.01" name="prix" class="form-control" required min="0.01">
            </div>

            <div class="mb-3">
                <label class="form-label">ID Bâtiment *</label>
                <input type="number" name="id_bat" class="form-control" required min="1">
            </div>

            <div class="mb-3">
                <label class="form-label">Numéro de chambre *</label>
                <input type="number" name="numero_ch" class="form-control" required min="1">
            </div>

            <div class="mb-3">
                <label class="form-label">Image de la chambre</label>
                <input type="file" name="image" class="form-control" accept="image/*">
            </div>

            <button type="submit" class="btn btn-primary">Ajouter</button>
        </form>

        <h3 class="mb-3">Liste des chambres</h3>
        <table class="table table-bordered table-hover bg-white shadow-sm align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Disponibilité</th>
                    <th>Prix</th>
                    <th>ID Bâtiment</th>
                    <th>Numéro chambre</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($chambres as $ch): ?>
                    <tr>
                        <td><?= htmlspecialchars($ch['numero']) ?></td>
                        <td><?= htmlspecialchars($ch['type']) ?></td>
                        <td><?= htmlspecialchars($ch['disponibilite']) ?></td>
                        <td><?= htmlspecialchars($ch['prix']) ?> $</td>
                        <td><?= htmlspecialchars($ch['id_bat']) ?></td>
                        <td><?= htmlspecialchars($ch['numero_ch']) ?></td>
                        <td>
                            <?php if (!empty($ch['image'])): ?>
                                <image src="<?= htmlspecialchars($ch['image']) ?>" class="image-thumbnail" alt="chambre">
                            <?php else: ?>
                                Aucune
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="modifier_chambre.php?id=<?= $ch['numero'] ?>" class="btn btn-warning btn-sm">Modifier</a>
                            <a href="?supprimer=<?= $ch['numero'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer cette chambre ?')">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($chambres)): ?>
                    <tr><td colspan="8" class="text-center">Aucune chambre trouvée.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
