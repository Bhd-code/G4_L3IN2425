<?php
session_start();

if (!isset($_SESSION['admin']['matricule'])) {
    header("Location: login.php");
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 1);
$page_title = "Tableau de bord Admin";
require_once __DIR__ . '/includes/config.php';

try {
    $stats = [
        'batiments' => $db->query("SELECT COUNT(*) FROM batiment")->fetchColumn(),
        'chambres' => $db->query("SELECT COUNT(*) FROM chambre")->fetchColumn(),
        'utilisateurs' => $db->query("SELECT COUNT(*) FROM etudiant")->fetchColumn(),
        'reservations' => $db->query("SELECT COUNT(*) FROM reservation")->fetchColumn()
    ];

    $stmt = $db->query("
        SELECT r.id_reser, r.date_reservation, 
               e.nom, e.prenom, c.numero
        FROM reservation r
        JOIN etudiant e ON r.matricule_etudiant = e.matricule
        JOIN chambre c ON r.numero_chambre = c.numero
        ORDER BY r.date_reservation DESC
        LIMIT 5
    ");
    $reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des données : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('../img/img2');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        h2 {
            text-align: center;
            font-weight: bold;
            color: #343a40;
        }

        .card {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .nav-links {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-right: auto;
        }

        .nav-links a {
            font-weight: 500;
            text-decoration: none;
            color: #0d6efd;
            padding-right: 10px;
        }

        .nav-links a:hover {
            text-decoration: underline;
        }

        .card-body {
            padding: 2rem;
        }

        .btn-outline-danger, .btn-outline-warning {
            border-radius: 0.5rem;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        @media (max-width: 768px) {
            .nav-links {
                justify-content: flex-start;
            }

            .nav-links a, .btn {
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>

<div class="container-fluid px-5 py-4">
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2 flex-wrap gap-2">
        <h1 class="h3">Tableau de bord - Admin</h1>

        <div class="d-flex flex-wrap align-items-center w-100 gap-3">
            <div class="nav-links">
                <a href="gestion_batiements.php"><i class="fas fa-building"></i> Bâtiments</a>
                <a href="gestion_chambres.php"><i class="fas fa-door-open"></i> Chambres</a>
                <a href="gestion_equipements.php"><i class="fas fa-tools"></i> Équipements</a>
                <a href="gestion_reservation.php"><i class="fas fa-calendar-alt"></i> Réservations</a>
            </div>
            <div class="ms-auto d-flex gap-2 flex-wrap">
                <a href="notifications.php" class="btn btn-outline-warning btn-sm text-nowrap" title="Notifications">
                    <i class="fas fa-bell"></i> Notifications
                </a>
                <a href="logout.php" class="btn btn-outline-danger btn-sm text-nowrap" title="Déconnexion">
                    <i class="fas fa-sign-out-alt"></i> Déconnexion
                </a>
            </div>
        </div>
    </div>

    <!-- Statistiques -->
    <div class="row mb-5">
        <div class="col-md-3">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body text-center">
                    <h5 class="card-title">Bâtiments</h5>
                    <p class="card-text display-4"><?= htmlspecialchars($stats['batiments']) ?></p>
                    <a href="gestion_batiements.php" class="text-white">Voir détails</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success mb-3">
                <div class="card-body text-center">
                    <h5 class="card-title">Chambres</h5>
                    <p class="card-text display-4"><?= htmlspecialchars($stats['chambres']) ?></p>
                    <a href="gestion_chambres.php" class="text-white">Voir détails</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info mb-3">
                <div class="card-body text-center">
                    <h5 class="card-title">Utilisateurs</h5>
                    <p class="card-text display-4"><?= htmlspecialchars($stats['utilisateurs']) ?></p>
                    <a href="gestion_utilisateurs.php" class="text-white">Voir détails</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning mb-3">
                <div class="card-body text-center">
                    <h5 class="card-title">Réservations</h5>
                    <p class="card-text display-4"><?= htmlspecialchars($stats['reservations']) ?></p>
                    <a href="gestion_reservation.php" class="text-white">Voir détails</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Réservations récentes -->
    <h2 class="mb-3">Dernières réservations</h2>
    <div class="table-responsive">
        <table class="table table-striped table-hover shadow-sm bg-white rounded">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Étudiant</th>
                    <th>Chambre</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservations as $res): ?>
                    <tr>
                        <td><?= htmlspecialchars($res['id_reser']) ?></td>
                        <td><?= htmlspecialchars($res['prenom'] . ' ' . $res['nom']) ?></td>
                        <td>Ch. <?= htmlspecialchars($res['numero']) ?></td>
                        <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($res['date_reservation']))) ?></td>
                        <td>
                            <a href="gestion_reservation.php?id=<?= urlencode($res['id_reser']) ?>" class="btn btn-sm btn-outline-primary" aria-label="Gérer la réservation">
                                <i class="fas fa-eye"></i> Voir
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($reservations)): ?>
                    <tr><td colspan="5" class="text-center text-muted">Aucune réservation récente</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
