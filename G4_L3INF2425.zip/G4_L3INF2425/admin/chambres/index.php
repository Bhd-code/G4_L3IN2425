<?php
$page_title = "Gestion des chambres";
require_once __DIR__ . '/../includes/auth.php';

// Filtres
$filters = [
    'disponibilite' => $_GET['disponibilite'] ?? null,
    'type' => $_GET['type'] ?? null,
    'batiment' => $_GET['batiment'] ?? null
];

// Construction de la requête
$query = "SELECT c.*, b.nom_batiment 
          FROM chambre c 
          JOIN batiment b ON c.id_bat = b.id_bat 
          WHERE 1=1";
$params = [];

foreach ($filters as $key => $value) {
    if (!empty($value)) {
        if ($key === 'batiment') {
            // Attention : le champ 'batiment' est 'id_bat' en table chambre
            $query .= " AND c.id_bat = ?";
        } else {
            $query .= " AND c.$key = ?";
        }
        $params[] = $value;
    }
}

$query .= " ORDER BY c.numero DESC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$chambres = $stmt->fetchAll();

// Récupération des bâtiments pour le filtre
$batiments = $db->query("SELECT id_bat, nom_batiment FROM batiment ORDER BY nom_batiment")->fetchAll();

function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Gestion des chambres</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="ajouter.php" class="btn btn-success">
                        <i class="fas fa-plus"></i> Ajouter
                    </a>
                </div>
            </div>

            <!-- Filtres -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="get" class="row g-3">
                        <div class="col-md-3">
                            <label for="disponibilite" class="form-label">Disponibilité</label>
                            <select id="disponibilite" name="disponibilite" class="form-select">
                                <option value="">Toutes</option>
                                <option value="oui" <?= $filters['disponibilite'] === 'oui' ? 'selected' : '' ?>>Disponible</option>
                                <option value="non" <?= $filters['disponibilite'] === 'non' ? 'selected' : '' ?>>Occupée</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="type" class="form-label">Type</label>
                            <select id="type" name="type" class="form-select">
                                <option value="">Tous</option>
                                <option value="simple" <?= $filters['type'] === 'simple' ? 'selected' : '' ?>>Simple</option>
                                <option value="studio" <?= $filters['type'] === 'studio' ? 'selected' : '' ?>>Studio</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="batiment" class="form-label">Bâtiment</label>
                            <select id="batiment" name="batiment" class="form-select">
                                <option value="">Tous</option>
                                <?php foreach ($batiments as $bat): ?>
                                <option value="<?= $bat['id_bat'] ?>" <?= $filters['batiment'] == $bat['id_bat'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($bat['nom_batiment']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-filter"></i> Filtrer
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tableau des chambres -->
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Numéro</th>
                            <th>Type</th>
                            <th>Bâtiment</th>
                            <th>Disponibilité</th>
                            <th>Prix</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($chambres as $chambre): ?>
                        <tr>
                            <td><?= $chambre['numero'] ?></td>
                            <td><?= ucfirst($chambre['type']) ?></td>
                            <td><?= htmlspecialchars($chambre['nom_batiment']) ?></td>
                            <td>
                                <span class="badge bg-<?= $chambre['disponibilite'] === 'oui' ? 'success' : 'danger' ?>">
                                    <?= $chambre['disponibilite'] === 'oui' ? 'Disponible' : 'Occupée' ?>
                                </span>
                            </td>
                            <td><?= number_format($chambre['prix'], 2) ?> $</td>
                            <td>
                                <a href="modifier.php?id=<?= $chambre['numero'] ?>" class="btn btn-sm btn-primary" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="post" action="delete.php" class="d-inline">
                                    <input type="hidden" name="id" value="<?= $chambre['numero'] ?>">
                                    <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" 
                                            onclick="return confirm('Supprimer cette chambre?')"
                                            title="Supprimer">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($chambres)): ?>
                        <tr>
                            <td colspan="6" class="text-center">Aucune chambre trouvée.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
