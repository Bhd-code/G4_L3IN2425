<?php
$page_title = "Ajouter une chambre";
require_once __DIR__ . '/../includes/auth.php';

// Génère un token CSRF si absent
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérification du token CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['flash_error'] = "Token CSRF invalide.";
        header("Location: ajouter.php");
        exit();
    }

    $data = [
        'numero' => (int)($_POST['numero'] ?? 0),
        'type' => $_POST['type'] ?? '',
        'prix' => (float)($_POST['prix'] ?? 0),
        'id_bat' => (int)($_POST['id_bat'] ?? 0),
        'disponibilite' => 'oui' // Par défaut
    ];

    // Validation simple
    $types_valides = ['simple', 'studio'];
    if ($data['numero'] <= 0) {
        $_SESSION['flash_error'] = "Le numéro doit être un entier positif.";
    } elseif (!in_array($data['type'], $types_valides)) {
        $_SESSION['flash_error'] = "Type de chambre invalide.";
    } elseif ($data['prix'] <= 0) {
        $_SESSION['flash_error'] = "Le prix doit être strictement positif.";
    } elseif ($data['id_bat'] <= 0) {
        $_SESSION['flash_error'] = "Veuillez sélectionner un bâtiment valide.";
    } else {
        try {
            $stmt = $db->prepare("
                INSERT INTO chambre (numero, type, prix, id_bat, disponibilite)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute(array_values($data));
            
            $_SESSION['flash_success'] = "Chambre ajoutée avec succès";
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            $_SESSION['flash_error'] = "Erreur : " . $e->getMessage();
        }
    }
}

// Récupération des bâtiments
$batiments = $db->query("SELECT id_bat, nom_batiment FROM batiment ORDER BY nom_batiment")->fetchAll();
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Ajouter une chambre</h1>
            </div>

            <?php if (!empty($_SESSION['flash_error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['flash_error'] ?></div>
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>
            
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="numero" class="form-label">Numéro *</label>
                            <input type="number" class="form-control" id="numero" name="numero" required min="1" value="<?= htmlspecialchars($_POST['numero'] ?? '') ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="type" class="form-label">Type *</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="simple" <?= (($_POST['type'] ?? '') === 'simple') ? 'selected' : '' ?>>Simple</option>
                                <option value="studio" <?= (($_POST['type'] ?? '') === 'studio') ? 'selected' : '' ?>>Studio</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="prix" class="form-label">Prix (USD) *</label>
                            <input type="number" step="0.01" class="form-control" id="prix" name="prix" required min="0" value="<?= htmlspecialchars($_POST['prix'] ?? '') ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="id_bat" class="form-label">Bâtiment *</label>
                            <select class="form-select" id="id_bat" name="id_bat" required>
                                <option value="">-- Choisir un bâtiment --</option>
                                <?php foreach ($batiments as $bat): ?>
                                <option value="<?= $bat['id_bat'] ?>" <?= (($_POST['id_bat'] ?? '') == $bat['id_bat']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($bat['nom_batiment']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Enregistrer
                    </button>
                    <a href="index.php" class="btn btn-secondary">Annuler</a>
                </div>
            </form>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
