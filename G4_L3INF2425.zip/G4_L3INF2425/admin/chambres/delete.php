<?php
require_once __DIR__ . '/../includes/auth.php';

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    die("Accès interdit");
}

$id = (int)$_POST['id'];

try {
    // Vérifier les réservations actives
    $stmt = $db->prepare("SELECT COUNT(*) FROM reservation WHERE numero_chambre = ?");
    $stmt->execute([$id]);
    $reservations = $stmt->fetchColumn();

    if ($reservations > 0) {
        $_SESSION['flash_error'] = "Impossible de supprimer: chambre a des réservations actives";
        header("Location: index.php");
        exit();
    }

    // Vérifier les équipements
    $stmt = $db->prepare("SELECT COUNT(*) FROM equipement WHERE numero_chambre = ?");
    $stmt->execute([$id]);
    $equipements = $stmt->fetchColumn();

    if ($equipements > 0) {
        $_SESSION['flash_error'] = "Impossible de supprimer: chambre contient des équipements";
        header("Location: index.php");
        exit();
    }

    // Suppression
    $stmt = $db->prepare("DELETE FROM chambre WHERE numero = ?");
    $stmt->execute([$id]);

    $_SESSION['flash_success'] = "Chambre supprimée avec succès";
} catch (PDOException $e) {
    $_SESSION['flash_error'] = "Erreur: " . $e->getMessage();
}

header("Location: index.php");
exit();
