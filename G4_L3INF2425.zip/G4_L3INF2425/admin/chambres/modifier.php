<?php
$page_title = "Modifier une chambre";
require_once __DIR__ . '/../includes/auth.php';

// Vérifie si l'ID est présent
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];

// Récupère les données de la chambre
$stmt = $db->prepare("
    SELECT c.*, b.nom_batiment 
    FROM chambre c
    JOIN batiment b ON c.id_bat = b.id_bat
    WHERE c.numero = ?
");
$stmt->execute([$id]);
$chambre = $stmt->fetch();

if (!$chambre) {
    $_SESSION['flash_error'] = "Chambre introuvable.";
    header("Location: index.php");
    exit();
}

// Génère un token CSRF si absent
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifie le token CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['flash_error'] = "Token CSRF invalide.";
        header("Location: modifier.php?id=$id");
        exit();
    }

    $type = $_POST['type'] ?? '';
    $prix = (float)($_POST['prix'] ?? 0);
    $id_bat = (int)($_POST['id_bat'] ?? 0);
    $disponibilite = $_POST['disponibilite'] ?? '';

    // Validation simple
    $types_valides = ['simple', 'studio'];
    $dispo_valides = ['oui', 'non'];

    if (!in_array($type, $types_valides) || !in_array($disponibilite, $dispo_valides) || $prix < 0) {
        $_SESSION['flash_error'] = "Données invalides.";
    } else {
        try {
            $update = $db->prepare("
                UPDATE chambre 
                SET type = ?, prix = ?, id_bat = ?, disponibilite = ?
                WHERE numero = ?
            ");
            $update->execute([$type, $prix, $id_bat, $disponibilite, $id]);

            $_SESSION['flash_success'] = "Chambre mise à jour avec succès.";
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            $_SESSION['flash_error'] = "Erreur lors de la mise à jour : " . $e->getMessage();
        }
    }
}

// Liste des bâtiments
$batiments = $db->query("SELECT id_bat, nom_batiment FROM batiment ORDER BY nom_batiment")->fetchAll();
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Modifier la chambre #<?= $chambre['numero'] ?></h1>
            </div>

            <?php if (!empty($_SESSION['flash_error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['flash_error'] ?></div>
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>

            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Numéro</label>
                            <input type="text" class="form-control-plaintext" value="<?= $chambre['numero'] ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="type" class="form-label">Type *</label>
                            <select class="form-select" name="type" id="type" required>
                                <option value="simple" <?= $chambre['type'] === 'simple' ? 'selected' : '' ?>>Simple</option>
                                <option value="studio" <?= $chambre['type'] === 'studio' ? 'selected' : '' ?>>Studio</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="prix" class="form-label">Prix (USD) *</label>
                            <input type="number" step="0.01" min="0" name="prix" id="prix" class="form-control" 
                                   value="<?= htmlspecialchars($chambre['prix']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="disponibilite" class="form-label">Disponibilité *</label>
                            <select class="form-select" name="disponibilite" id="disponibilite" required>
                                <option value="oui" <?= $chambre['disponibilite'] === 'oui' ? 'selected' : '' ?>>Disponible</option>
                                <option value="non" <?= $chambre['disponibilite'] === 'non' ? 'selected' : '' ?>>Occupée</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="mb-3">
                            <label for="id_bat" class="form-label">Bâtiment *</label>
                            <select class="form-select" name="id_bat" id="id_bat" required>
                                <?php foreach ($batiments as $bat): ?>
                                    <option value="<?= $bat['id_bat'] ?>" 
                                            <?= $bat['id_bat'] == $chambre['id_bat'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($bat['nom_batiment']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Enregistrer
                    </button>
                    <a href="index.php" class="btn btn-secondary">Annuler</a>
                </div>
            </form>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
