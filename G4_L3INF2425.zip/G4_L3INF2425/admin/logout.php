<?php
session_start();
if(!$_SESSION["admin"]['matricule']){
    header("location: connecter.php");
}

unset($_SESSION["admin"]['matricule']);

header("location: inde2.php");