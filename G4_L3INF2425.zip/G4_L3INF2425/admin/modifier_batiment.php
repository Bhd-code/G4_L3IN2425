<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = $db->prepare("SELECT * FROM batiment WHERE id_bat = ?");
$stmt->execute([$id]);
$batiment = $stmt->fetch();

if (!$batiment) {
    echo "Bâtiment introuvable.";
    exit;
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nbre_ch = filter_input(INPUT_POST, 'nbre_ch', FILTER_VALIDATE_INT);
    $section = trim($_POST['section'] ?? '');
    $statut = trim($_POST['statut'] ?? '');

    if (!$nbre_ch || $nbre_ch <= 0) $errors[] = "Le nombre de chambres est invalide.";
    if (empty($section)) $errors[] = "Section manquante.";
    if (empty($statut)) $errors[] = "Statut manquant.";

    if (empty($errors)) {
        $stmt = $db->prepare("UPDATE batiment SET nbre_ch=?, section=?, statut=? WHERE id_bat=?");
        $stmt->execute([$nbre_ch, $section, $statut, $id]);
        $success = "Mise à jour réussie.";
        header("Location: gestion_batiements.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un bâtiment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../img/img2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .overlay {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.3);
            margin-top: 4rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="overlay">
        <h2 class="mb-4">Modifier le bâtiment</h2>

        <?php if ($errors): ?>
            <div class="alert alert-danger">
                <ul><?php foreach ($errors as $e) echo "<li>" . htmlspecialchars($e) . "</li>"; ?></ul>
            </div>
        <?php endif; ?>

        <form method="post" class="card p-4 shadow-sm">
            <div class="mb-3">
                <label>Nombre de chambres *</label>
                <input type="number" name="nbre_ch" class="form-control" required value="<?= htmlspecialchars($batiment['nbre_ch']) ?>">
            </div>
            <div class="mb-3">
                <label>Section *</label>
                <input type="text" name="section" class="form-control" required value="<?= htmlspecialchars($batiment['section']) ?>">
            </div>
            <div class="mb-3">
                <label>Statut *</label>
                <input type="text" name="statut" class="form-control" required value="<?= htmlspecialchars($batiment['statut']) ?>">
            </div>
            <button type="submit" class="btn btn-primary">Mettre à jour</button>
            <a href="gestion_batiements.php" class="btn btn-secondary">Annuler</a>
        </form>
    </div>
</div>
</body>
</html>
