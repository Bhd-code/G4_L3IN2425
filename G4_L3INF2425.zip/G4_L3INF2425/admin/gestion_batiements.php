<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

$errors = [];
$success = '';

// Suppression d'un bâtiment sans redirection
if (isset($_GET['supprimer'])) {
    $id = (int) $_GET['supprimer'];
    if ($id > 0) {
        try {
            $stmt = $db->prepare("DELETE FROM batiment WHERE id_bat = ?");
            $stmt->execute([$id]);
            $success = "Bâtiment supprimé avec succès.";
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la suppression : " . $e->getMessage();
        }
    } else {
        $errors[] = "ID invalide pour suppression.";
    }
}

// Traitement du formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nbre_ch = filter_input(INPUT_POST, 'nbre_ch', FILTER_VALIDATE_INT);
    $section = trim($_POST['section'] ?? '');
    $statut = trim($_POST['statut'] ?? '');

    if (!$nbre_ch || $nbre_ch <= 0) $errors[] = "Le nombre de chambres doit être un entier positif.";
    if (empty($section)) $errors[] = "La section est obligatoire.";
    if (empty($statut)) $errors[] = "Le statut est obligatoire.";

    if (empty($errors)) {
        try {
            $stmt = $db->prepare("INSERT INTO batiment (nbre_ch, section, statut) VALUES (?, ?, ?)");
            $stmt->execute([$nbre_ch, $section, $statut]);
            $success = "Bâtiment ajouté avec succès.";
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de l'ajout : " . $e->getMessage();
        }
    }
}

// Récupération des bâtiments mise à jour (après ajout ou suppression)
$batiments = $db->query("SELECT * FROM batiment ORDER BY id_bat DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des bâtiments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../img/img2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
        }
        .overlay {
            background-color: rgba(255, 255, 255, 0.88);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }
        .top-right {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .btn-home {
            background-color: #0d6efd;
            color: white;
            font-weight: bold;
            border-radius: 30px;
            padding: 0.5rem 1rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        }
        .form-card {
            background-color: rgba(255, 255, 255, 0.93);
        }
    </style>
</head>
<body>

<div class="top-right">
    <a href="inde2.php" class="btn btn-home">🏠 Accueil</a>
</div>

<div class="container py-5">
    <div class="overlay">
        <h2 class="mb-4">Ajouter un bâtiment</h2>

        <?php if ($errors): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="post" class="card p-4 shadow-sm mb-5 form-card">
            <div class="mb-3">
                <label class="form-label">Nombre de chambres *</label>
                <input type="number" name="nbre_ch" class="form-control" required min="1">
            </div>
            <div class="mb-3">
                <label class="form-label">Section *</label>
                <input type="text" name="section" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Statut *</label>
                <input type="text" name="statut" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Ajouter</button>
        </form>

        <h3 class="mb-3">Liste des bâtiments</h3>
        <table class="table table-bordered table-hover bg-white shadow-sm">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Section</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($batiments as $b): ?>
                    <tr>
                        <td><?= $b['id_bat'] ?></td>
                        <td><?= htmlspecialchars($b['nbre_ch']) ?></td>
                        <td><?= htmlspecialchars($b['section']) ?></td>
                        <td><?= htmlspecialchars($b['statut']) ?></td>
                        <td>
                            <a href="modifier_batiment.php?id=<?= $b['id_bat'] ?>" class="btn btn-warning btn-sm">Modifier</a>
                            <a href="?supprimer=<?= $b['id_bat'] ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Supprimer ce bâtiment ?')">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
