<?php
session_start();

try {
    $db = new PDO('mysql:host=localhost;dbname=reservation_cite_universitaire;charset=utf8', 'root', '');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

$errors = [];
$success = '';

// Suppression sans redirection
if (isset($_GET['supprimer'])) {
    $id = (int) $_GET['supprimer'];
    if ($id > 0) {
        try {
            $stmt = $db->prepare("DELETE FROM equipement WHERE id_equi = ?");
            $stmt->execute([$id]);
            $success = "Équipement supprimé avec succès.";
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la suppression : " . $e->getMessage();
        }
    } else {
        $errors[] = "ID invalide pour suppression.";
    }
}

// Ajout d'un équipement
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $numero_chambre = filter_input(INPUT_POST, 'numero_chambre', FILTER_VALIDATE_INT);

    // Gestion de l'image
    $imageName = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $tmpName = $_FILES['image']['tmp_name'];
        $originalName = basename($_FILES['image']['name']);
        $imageName = uniqid() . '_' . $originalName;
        $targetPath = $uploadDir . $imageName;

        // Vérifier le type MIME
        $mimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array(mime_content_type($tmpName), $mimeTypes)) {
            $errors[] = "Le fichier doit être une image (jpg, png, gif, webp).";
        } else {
            move_uploaded_file($tmpName, $targetPath);
        }
    } else {
        $errors[] = "L'image est obligatoire.";
    }

    if (empty($nom)) {
        $errors[] = "Le nom de l'équipement est obligatoire.";
    }

    if (!$numero_chambre || $numero_chambre <= 0) {
        $errors[] = "Le numéro de chambre est invalide.";
    }

    if (empty($errors)) {
        try {
            $stmt = $db->prepare("INSERT INTO equipement (nom, description, image, numero_chambre) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nom, $description, $imageName, $numero_chambre]);
            $success = "Équipement ajouté avec succès.";
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de l'ajout : " . $e->getMessage();
        }
    }
}

// Récupération mise à jour
$equipements = $db->query("SELECT * FROM equipement ORDER BY id_equi DESC")->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des équipements</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../img/img2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0; padding: 0;
        }
        .overlay {
            background-color: rgba(255, 255, 255, 0.88);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }
        .top-right {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .btn-home {
            background-color: #0d6efd;
            color: white;
            font-weight: bold;
            border-radius: 30px;
            padding: 0.5rem 1rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            text-decoration: none;
        }
        .form-card {
            background-color: rgba(255, 255, 255, 0.93);
        }
        table img {
            border-radius: 6px;
            object-fit: cover;
        }
        /* Boutons petits et espacement */
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        .action-buttons > * {
            margin-right: 0.3rem;
        }
    </style>
</head>
<body>

<div class="top-right">
    <a href="inde2.php" class="btn-home">🏠 Accueil</a>
</div>

<div class="container py-5">
    <div class="overlay">
        <h2 class="mb-4">Ajouter un équipement</h2>

        <?php if ($errors): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="card p-4 shadow-sm mb-5 form-card">
            <div class="mb-3">
                <label class="form-label">Nom de l'équipement *</label>
                <input type="text" name="nom" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3"></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Image *</label>
                <input type="file" name="image" accept="image/*" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Numéro de chambre *</label>
                <input type="number" name="numero_chambre" class="form-control" required min="1">
            </div>

            <button type="submit" class="btn btn-primary">Ajouter</button>
        </form>

        <h3 class="mb-3">Liste des équipements</h3>
        <table class="table table-bordered table-hover bg-white shadow-sm align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Numéro chambre</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($equipements as $eq): ?>
                    <tr>
                        <td><?= htmlspecialchars($eq['id_equi']) ?></td>
                        <td><?= htmlspecialchars($eq['nom']) ?></td>
                        <td><?= htmlspecialchars($eq['description']) ?></td>
                        <td>
                            <?php if (!empty($eq['image']) && file_exists('uploads/' . $eq['image'])): ?>
                                <img src="uploads/<?= htmlspecialchars($eq['image']) ?>" alt="Image équipement" width="80" height="60">
                            <?php else: ?>
                                Aucune image
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($eq['numero_chambre']) ?></td>
                        <td class="action-buttons">
                            <a href="modifier_equipement.php?id=<?= $eq['id_equi'] ?>" class="btn btn-warning btn-sm">Modifier</a>
                            <a href="?supprimer=<?= $eq['id_equi'] ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Supprimer cet équipement ?')">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
