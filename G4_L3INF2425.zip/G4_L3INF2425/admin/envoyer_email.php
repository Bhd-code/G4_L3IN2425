<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $nom = $_POST["nom"];
    $date_debut = $_POST["date_debut"];
    $id = $_POST["id_reservation"];

    $sujet = "Notification : Réservation prolongée";
    $message = "Bonjour $nom,\n\nVotre réservation commencée le $date_debut a maintenant dépassé une semaine.\nMerci de vérifier si une action est nécessaire.\n\nCordialement,\nL'administration.";
    $headers = "From: admin@tonsite.com";

    if (mail($email, $sujet, $message, $headers)) {
        $conn = new mysqli("localhost", "root", "", "reservation_salle");
        if (!$conn->connect_error) {
            $conn->query("UPDATE reservation SET notification_envoyee = 1 WHERE id_reservation = $id");
            $conn->close();
        }
        echo "<p style='text-align:center; color:green;'>Email envoyé à <strong>$email</strong>.</p>";
    } else {
        echo "<p style='text-align:center; color:red;'>Échec de l'envoi à <strong>$email</strong>.</p>";
    }

    echo "<p style='text-align:center;'><a href='notifications.php'>← Retour</a></p>";
}
?>
