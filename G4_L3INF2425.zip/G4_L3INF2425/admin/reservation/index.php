<?php
$page_title = "Gestion des réservations";
require_once __DIR__ . '/../includes/auth.php';

// Fonction simple de validation de date au format Y-m-d
function validateDate(string $date): ?string {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return ($d && $d->format('Y-m-d') === $date) ? $date : null;
}

// Récupération et validation des filtres
$filters = [
    'date_debut' => isset($_GET['date_debut']) ? validateDate($_GET['date_debut']) : null,
    'date_fin' => isset($_GET['date_fin']) ? validateDate($_GET['date_fin']) : date('Y-m-d'),
    'statut' => in_array($_GET['statut'] ?? 'active', ['active', 'historique']) ? $_GET['statut'] : 'active',
];

// Construction de la requête avec filtres
$query = "SELECT r.*, 
                 e.nom AS etudiant_nom, e.prenom AS etudiant_prenom, e.matricule,
                 c.numero AS chambre_numero, c.type AS chambre_type,
                 b.nom_batiment
          FROM reservation r
          JOIN etudiant e ON r.matricule_etudiant = e.matricule
          JOIN chambre c ON r.numero_chambre = c.numero
          JOIN batiment b ON c.id_bat = b.id_bat
          WHERE 1=1";

$params = [];

// Filtre par date de réservation
if ($filters['date_debut']) {
    $query .= " AND r.date_reservation >= ?";
    $params[] = $filters['date_debut'] . ' 00:00:00';
}

if ($filters['date_fin']) {
    $query .= " AND r.date_reservation <= ?";
    $params[] = $filters['date_fin'] . ' 23:59:59';
}

// Filtre par statut
// Supposons qu'il y a un champ 'statut' dans reservation : 'active' ou 'terminée'
// Sinon, on peut filtrer par date de fin réelle ou date actuelle

if ($filters['statut'] === 'active') {
    $query .= " AND r.statut = 'active'";
} elseif ($filters['statut'] === 'historique') {
    $query .= " AND r.statut = 'terminée'";
}

$query .= " ORDER BY r.date_reservation DESC";

try {
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['flash_error'] = "Erreur lors de la récupération des réservations : " . $e->getMessage();
    $reservations = [];
}

// Génération d'un token CSRF simple
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Gestion des réservations</h1>
                <div class="btn-group">
                    <a href="?statut=active" class="btn btn-sm btn-<?= $filters['statut'] === 'active' ? 'primary' : 'outline-primary' ?>">
                        Actives
                    </a>
                    <a href="?statut=historique" class="btn btn-sm btn-<?= $filters['statut'] === 'historique' ? 'primary' : 'outline-primary' ?>">
                        Historique
                    </a>
                </div>
            </div>

            <?php if (isset($_SESSION['flash_error'])): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['flash_error']) ?></div>
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>

            <!-- Filtres -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="get" class="row g-3">
                        <input type="hidden" name="statut" value="<?= htmlspecialchars($filters['statut']) ?>">
                        
                        <div class="col-md-3">
                            <label for="date_debut" class="form-label">Date début</label>
                            <input type="date" class="form-control" id="date_debut" name="date_debut" 
                                   value="<?= htmlspecialchars($filters['date_debut'] ?? '') ?>">
                        </div>
                        
                        <div class="col-md-3">
                            <label for="date_fin" class="form-label">Date fin</label>
                            <input type="date" class="form-control" id="date_fin" name="date_fin" 
                                   value="<?= htmlspecialchars($filters['date_fin'] ?? '') ?>">
                        </div>
                        
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-filter"></i> Filtrer
                            </button>
                            <a href="index.php" class="btn btn-secondary">Réinitialiser</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tableau des réservations -->
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Étudiant</th>
                            <th>Chambre</th>
                            <th>Date</th>
                            <th>Paiement</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reservations)): ?>
                            <tr>
                                <td colspan="6" class="text-center">Aucune réservation trouvée.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($reservations as $res): ?>
                            <tr>
                                <td><?= htmlspecialchars($res['id_reser']) ?></td>
                                <td>
                                    <a href="../utilisateurs/modifier.php?matricule=<?= urlencode($res['matricule']) ?>">
                                        <?= htmlspecialchars($res['etudiant_prenom'] . ' ' . $res['etudiant_nom']) ?>
                                    </a>
                                    <small class="d-block text-muted"><?= htmlspecialchars($res['matricule']) ?></small>
                                </td>
                                <td>
                                    Ch. <?= htmlspecialchars($res['chambre_numero']) ?>
                                    <small class="d-block text-muted">
                                        <?= htmlspecialchars(ucfirst($res['chambre_type'])) ?> - <?= htmlspecialchars($res['nom_batiment']) ?>
                                    </small>
                                </td>
                                <td>
                                    <?= htmlspecialchars(date('d/m/Y H:i', strtotime($res['date_reservation']))) ?>
                                    <small class="d-block text-muted">
                                        <?= $filters['statut'] === 'active' ? 'Active' : 'Terminée' ?>
                                    </small>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $res['type_payement'] === 'Carte' ? 'success' : 'info' ?>">
                                        <?= htmlspecialchars($res['type_payement']) ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="details.php?id=<?= urlencode($res['id_reser']) ?>" class="btn btn-sm btn-primary" title="Voir détails">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <?php if ($filters['statut'] === 'active'): ?>
                                    <button class="btn btn-sm btn-danger" 
                                            onclick="confirmAnnulation(<?= (int)$res['id_reser'] ?>, '<?= htmlspecialchars(addslashes($res['etudiant_prenom'] . ' ' . $res['etudiant_nom'])) ?>')"
                                            title="Annuler la réservation">
                                        <i class="fas fa-times"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Formulaire d'annulation caché -->
            <form id="annulationForm" method="post" action="annuler.php">
                <input type="hidden" name="id_reser" id="annulationId">
                <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
            </form>
        </main>
    </div>
</div>

<script>
function confirmAnnulation(id, name) {
    Swal.fire({
        title: 'Confirmer l\'annulation',
        html: `Annuler la réservation de <b>${name}</b> ?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Oui, annuler',
        cancelButtonText: 'Non'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('annulationId').value = id;
            document.getElementById('annulationForm').submit();
        }
    });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
