<?php
require_once __DIR__ . '/../includes/auth.php';

// Vérification CSRF
if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    die("Accès interdit");
}

$id = (int)($_POST['id_reser'] ?? 0);

if (!$id) {
    $_SESSION['flash_error'] = "ID de réservation invalide.";
    header("Location: index.php");
    exit;
}

try {
    // Récupération des informations de la réservation
    $stmt = $db->prepare("
        SELECT r.numero_chambre 
        FROM reservation r
        JOIN chambre c ON r.numero_chambre = c.numero
        WHERE r.id_reser = ? AND c.disponibilite = 'non'
    ");
    $stmt->execute([$id]);
    $reservation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$reservation) {
        throw new Exception("Réservation introuvable ou déjà annulée.");
    }

    // Début de la transaction
    $db->beginTransaction();

    // Suppression de la réservation
    $stmt = $db->prepare("DELETE FROM reservation WHERE id_reser = ?");
    $stmt->execute([$id]);

    // Mise à jour de la disponibilité de la chambre
    $stmt = $db->prepare("UPDATE chambre SET disponibilite = 'oui' WHERE numero = ?");
    $stmt->execute([$reservation['numero_chambre']]);

    // Validation de la transaction
    $db->commit();
    $_SESSION['flash_success'] = "Réservation annulée avec succès.";
} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    $_SESSION['flash_error'] = "Erreur lors de l'annulation : " . $e->getMessage();
}

header("Location: index.php");
exit;
