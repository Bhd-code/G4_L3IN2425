<?php
$page_title = "Détails de réservation";
require_once __DIR__ . '/../includes/auth.php';

// Vérification de l'ID
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];

// Récupération des données
$stmt = $db->prepare("
    SELECT r.*, 
           e.nom as etudiant_nom, e.prenom as etudiant_prenom, e.matricule, e.email, e.tel, e.faculte,
           c.numero as chambre_numero, c.type as chambre_type, c.prix, c.disponibilite,
           b.nom_batiment, b.section
    FROM reservation r
    JOIN etudiant e ON r.matricule_etudiant = e.matricule
    JOIN chambre c ON r.numero_chambre = c.numero
    JOIN batiment b ON c.id_bat = b.id_bat
    WHERE r.id_reser = ?
");
$stmt->execute([$id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation) {
    header("Location: index.php");
    exit();
}
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Détails de la réservation #<?= $reservation['id_reser'] ?></h1>
                <span class="badge bg-<?= $reservation['disponibilite'] === 'non' ? 'success' : 'secondary' ?>">
                    <?= $reservation['disponibilite'] === 'non' ? 'Active' : 'Terminée' ?>
                </span>
            </div>

            <div class="row">
                <!-- Informations Étudiant -->
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0">Informations étudiant</h5>
                        </div>
                        <div class="card-body">
                            <dl class="row">
                                <dt class="col-sm-4">Nom complet</dt>
                                <dd class="col-sm-8"><?= htmlspecialchars($reservation['etudiant_prenom'] . ' ' . $reservation['etudiant_nom']) ?></dd>
                                
                                <dt class="col-sm-4">Matricule</dt>
                                <dd class="col-sm-8"><?= htmlspecialchars($reservation['matricule']) ?></dd>
                                
                                <dt class="col-sm-4">Email</dt>
                                <dd class="col-sm-8"><?= htmlspecialchars($reservation['email']) ?></dd>
                                
                                <dt class="col-sm-4">Téléphone</dt>
                                <dd class="col-sm-8"><?= htmlspecialchars($reservation['tel']) ?></dd>
                                
                                <dt class="col-sm-4">Faculté</dt>
                                <dd class="col-sm-8"><?= htmlspecialchars($reservation['faculte']) ?></dd>
                            </dl>
                            <a href="../utilisateurs/modifier.php?matricule=<?= $reservation['matricule'] ?>" class="btn btn-sm btn-outline-primary">
                                Voir fiche étudiant
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Informations Chambre -->
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0">Informations chambre</h5>
                        </div>
                        <div class="card-body">
                            <dl class="row">
                                <dt class="col-sm-4">Numéro</dt>
                                <dd class="col-sm-8"><?= htmlspecialchars($reservation['chambre_numero']) ?></dd>
                                
                                <dt class="col-sm-4">Type</dt>
                                <dd class="col-sm-8"><?= ucfirst(htmlspecialchars($reservation['chambre_type'])) ?></dd>
                                
                                <dt class="col-sm-4">Bâtiment</dt>
                                <dd class="col-sm-8"><?= htmlspecialchars($reservation['nom_batiment']) ?> (<?= ucfirst(htmlspecialchars($reservation['section'])) ?>)</dd>
                                
                                <dt class="col-sm-4">Prix</dt>
                                <dd class="col-sm-8"><?= number_format($reservation['prix'], 2) ?> $</dd>
                                
                                <dt class="col-sm-4">Disponibilité</dt>
                                <dd class="col-sm-8">
                                    <span class="badge bg-<?= $reservation['disponibilite'] === 'non' ? 'danger' : 'success' ?>">
                                        <?= $reservation['disponibilite'] === 'non' ? 'Occupée' : 'Disponible' ?>
                                    </span>
                                </dd>
                            </dl>
                            <a href="../chambres/modifier.php?id=<?= $reservation['chambre_numero'] ?>" class="btn btn-sm btn-outline-primary">
                                Voir fiche chambre
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Détails de la réservation -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Détails de la réservation</h5>
                </div>
                <div class="card-body">
                    <dl class="row">
                        <dt class="col-sm-3">Date réservation</dt>
                        <dd class="col-sm-9"><?= date('d/m/Y H:i', strtotime($reservation['date_reservation'])) ?></dd>
                        
                        <dt class="col-sm-3">Mode paiement</dt>
                        <dd class="col-sm-9">
                            <span class="badge bg-<?= $reservation['type_payement'] === 'Carte' ? 'success' : 'info' ?>">
                                <?= htmlspecialchars($reservation['type_payement']) ?>
                            </span>
                        </dd>
                        
                        <dt class="col-sm-3">Statut</dt>
                        <dd class="col-sm-9">
                            <span class="badge bg-<?= $reservation['disponibilite'] === 'non' ? 'success' : 'secondary' ?>">
                                <?= $reservation['disponibilite'] === 'non' ? 'Active' : 'Terminée' ?>
                            </span>
                        </dd>
                    </dl>

                    <!-- Bouton d’annulation -->
                    <?php if ($reservation['disponibilite'] === 'non'): ?>
                    <form method="post" action="annuler.php" class="mt-3">
                        <input type="hidden" name="id_reser" value="<?= $reservation['id_reser'] ?>">
                        <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Annuler cette réservation ?')">
                            <i class="fas fa-times"></i> Annuler la réservation
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
