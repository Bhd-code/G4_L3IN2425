<?php
$page_title = "Statistiques et rapports";
require_once __DIR__ . '/../includes/auth.php';

// Période par défaut (30 derniers jours)
$dateDebut = date('Y-m-d', strtotime('-30 days'));
$dateFin = date('Y-m-d');

// Récupération des données statistiques
$stats = [
    // Réservations par période
    'reservations_periodes' => $db->query("
        SELECT DATE_FORMAT(date_reservation, '%Y-%m-%d') AS jour, 
               COUNT(*) AS total
        FROM reservation
        WHERE date_reservation BETWEEN '$dateDebut' AND '$dateFin 23:59:59'
        GROUP BY jour
        ORDER BY jour
    ")->fetchAll(),

    // Occupation par bâtiment
    'occupation_batiments' => $db->query("
        SELECT b.nom_batiment, 
               COUNT(c.numero) AS total_chambres,
               SUM(CASE WHEN c.disponibilite = 'non' THEN 1 ELSE 0 END) AS occupees
        FROM batiment b
        LEFT JOIN chambre c ON b.id_bat = c.id_bat
        GROUP BY b.id_bat
        ORDER BY b.nom_batiment
    ")->fetchAll(),

    // Types de chambres
    'types_chambres' => $db->query("
        SELECT type, COUNT(*) AS total
        FROM chambre
        GROUP BY type
    ")->fetchAll(),

    // Moyenne de réservations
    'stats_generales' => $db->query("
        SELECT 
            COUNT(*) AS total_reservations,
            COUNT(DISTINCT matricule_etudiant) AS etudiants_uniques,
            AVG(DATEDIFF(NOW(), date_reservation)) AS duree_moyenne
        FROM reservation
    ")->fetch(),

    // Dernières activités
    'activites_recentes' => $db->query("
        SELECT 
            e.nom, e.prenom, e.matricule,
            r.date_reservation,
            c.numero AS chambre_numero,
            b.nom_batiment
        FROM reservation r
        JOIN etudiant e ON r.matricule_etudiant = e.matricule
        JOIN chambre c ON r.numero_chambre = c.numero
        JOIN batiment b ON c.id_bat = b.id_bat
        ORDER BY r.date_reservation DESC
        LIMIT 5
    ")->fetchAll()
];
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<!-- Intégration de Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Statistiques et rapports</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="exportPdf">
                            <i class="fas fa-file-pdf"></i> Export PDF
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="exportExcel">
                            <i class="fas fa-file-excel"></i> Export Excel
                        </button>
                    </div>
                </div>
            </div>

            <!-- Cartes de statistiques -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card text-white bg-primary">
                        <div class="card-body">
                            <h5 class="card-title">Réservations totales</h5>
                            <p class="card-text display-4"><?= $stats['stats_generales']['total_reservations'] ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <h5 class="card-title">Étudiants uniques</h5>
                            <p class="card-text display-4"><?= $stats['stats_generales']['etudiants_uniques'] ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-info">
                        <div class="card-body">
                            <h5 class="card-title">Durée moyenne</h5>
                            <p class="card-text display-4"><?= round($stats['stats_generales']['duree_moyenne']) ?> jours</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-warning">
                        <div class="card-body">
                            <h5 class="card-title">Taux d'occupation</h5>
                            <?php
                            $totalChambres = array_sum(array_column($stats['occupation_batiments'], 'total_chambres'));
                            $occupees = array_sum(array_column($stats['occupation_batiments'], 'occupees'));
                            $taux = $totalChambres > 0 ? round(($occupees / $totalChambres) * 100) : 0;
                            ?>
                            <p class="card-text display-4"><?= $taux ?>%</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Graphiques -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>Réservations par période</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="chartReservations" height="250"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>Répartition des types de chambres</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="chartTypesChambres" height="250"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>Occupation par bâtiment</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="chartOccupation" height="150"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dernières activités -->
            <div class="card">
                <div class="card-header">
                    <h5>Dernières réservations</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Étudiant</th>
                                    <th>Chambre</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stats['activites_recentes'] as $activite): ?>
                                <tr>
                                    <td>
                                        <?= htmlspecialchars($activite['prenom'] . ' ' . $activite['nom']) ?>
                                        <small class="d-block text-muted"><?= $activite['matricule'] ?></small>
                                    </td>
                                    <td>
                                        Ch. <?= $activite['chambre_numero'] ?>
                                        <small class="d-block text-muted"><?= $activite['nom_batiment'] ?></small>
                                    </td>
                                    <td><?= date('d/m/Y H:i', strtotime($activite['date_reservation'])) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
// Graphique des réservations par période
const ctx1 = document.getElementById('chartReservations').getContext('2d');
new Chart(ctx1, {
    type: 'line',
    data: {
        labels: [<?= implode(',', array_map(function($r) { return "'" . date('d/m', strtotime($r['jour'])) . "'"; }, $stats['reservations_periodes'])) ?>],
        datasets: [{
            label: 'Réservations',
            data: [<?= implode(',', array_column($stats['reservations_periodes'], 'total')) ?>],
            borderColor: 'rgba(75, 192, 192, 1)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            tension: 0.1,
            fill: true
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// Graphique des types de chambres
const ctx2 = document.getElementById('chartTypesChambres').getContext('2d');
new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: [<?= implode(',', array_map(function($t) { return "'" . ucfirst($t['type']) . "'"; }, $stats['types_chambres'])) ?>],
        datasets: [{
            data: [<?= implode(',', array_column($stats['types_chambres'], 'total')) ?>],
            backgroundColor: [
                'rgba(54, 162, 235, 0.7)',
                'rgba(255, 99, 132, 0.7)',
                'rgba(255, 206, 86, 0.7)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'right'
            },
            datalabels: {
                formatter: (value) => {
                    return value + ' (' + Math.round(value / <?= array_sum(array_column($stats['types_chambres'], 'total')) ?> * 100) + '%)';
                },
                color: '#fff',
                font: {
                    weight: 'bold'
                }
            }
        }
    },
    plugins: [ChartDataLabels]
});

// Graphique d'occupation par bâtiment
const ctx3 = document.getElementById('chartOccupation').getContext('2d');
new Chart(ctx3, {
    type: 'bar',
    data: {
        labels: [<?= implode(',', array_map(function($b) { return "'" . $b['nom_batiment'] . "'"; }, $stats['occupation_batiments'])) ?>],
        datasets: [
            {
                label: 'Chambres occupées',
                data: [<?= implode(',', array_column($stats['occupation_batiments'], 'occupees')) ?>],
                backgroundColor: 'rgba(255, 99, 132, 0.7)'
            },
            {
                label: 'Chambres disponibles',
                data: [<?= implode(',', array_map(function($b) { return $b['total_chambres'] - $b['occupees']; }, $stats['occupation_batiments'])) ?>],
                backgroundColor: 'rgba(75, 192, 192, 0.7)'
            }
        ]
    },
    options: {
        responsive: true,
        scales: {
            x: {
                stacked: true
            },
            y: {
                stacked: true
            }
        }
    }
});

// Boutons d'export
document.getElementById('exportPdf').addEventListener('click', function() {
    window.print();
});

document.getElementById('exportExcel').addEventListener('click', function() {
    // Ici vous pourriez implémenter un export réel vers Excel
    alert('Export Excel sera implémenté ici');
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>