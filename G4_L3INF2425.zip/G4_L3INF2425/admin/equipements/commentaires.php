<?php
$page_title = "Gestion des commentaires";
require_once __DIR__ . '/../includes/auth.php';

// Vérification de l'ID équipement
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id_equi = (int)$_GET['id'];

// Récupération de l'équipement
$stmt = $db->prepare("
    SELECT e.*, c.numero as chambre_numero, b.nom_batiment
    FROM equipement e
    LEFT JOIN chambre c ON e.numero_chambre = c.numero
    LEFT JOIN batiment b ON c.id_bat = b.id_bat
    WHERE e.id_equi = ?
");
$stmt->execute([$id_equi]);
$equipement = $stmt->fetch();

if (!$equipement) {
    header("Location: index.php");
    exit();
}

// Traitement des actions (suppression de commentaire)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérification CSRF
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        die("Accès interdit");
    }

    if (isset($_POST['delete_comment'])) {
        // Suppression d'un commentaire
        $id_com = (int)$_POST['id_com'];
        $stmt = $db->prepare("DELETE FROM commentaire WHERE id_com = ?");
        $stmt->execute([$id_com]);
        $_SESSION['flash_success'] = "Commentaire supprimé";
        header("Location: commentaires.php?id=$id_equi");
        exit();
    }
}

// Récupération des commentaires
$stmt = $db->prepare("
    SELECT c.*, e.nom as etudiant_nom, e.prenom as etudiant_prenom, e.matricule
    FROM commentaire c
    JOIN etudiant e ON c.matricule_etudiant = e.matricule
    WHERE c.id_equi = ?
    ORDER BY c.date_envoie DESC
");
$stmt->execute([$id_equi]);
$commentaires = $stmt->fetchAll();
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Commentaires pour : <?= htmlspecialchars($equipement['nom']) ?></h1>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Retour
                </a>
            </div>

            <?php if ($equipement['numero_chambre']): ?>
            <div class="alert alert-info">
                Localisation : Ch. <?= $equipement['chambre_numero'] ?> - <?= htmlspecialchars($equipement['nom_batiment']) ?>
            </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0">Liste des commentaires</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($commentaires)): ?>
                            <div class="alert alert-info">Aucun commentaire pour cet équipement</div>
                            <?php else: ?>
                            <div class="list-group">
                                <?php foreach ($commentaires as $com): ?>
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">
                                            <?= htmlspecialchars($com['etudiant_prenom'] . ' ' . $com['etudiant_nom']) ?>
                                            <small class="text-muted">(<?= $com['matricule'] ?>)</small>
                                        </h6>
                                        <small><?= date('d/m/Y H:i', strtotime($com['date_envoie'])) ?></small>
                                    </div>
                                    <p class="mb-1"><?= nl2br(htmlspecialchars($com['message'])) ?></p>
                                    <form method="post" class="text-end">
                                        <input type="hidden" name="id_com" value="<?= $com['id_com'] ?>">
                                        <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                                        <button type="submit" name="delete_comment" class="btn btn-sm btn-danger"
                                                onclick="return confirm('Supprimer ce commentaire ?')">
                                            <i class="fas fa-trash-alt"></i> Supprimer
                                        </button>
                                    </form>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0">Détails de l'équipement</h5>
                        </div>
                        <div class="card-body text-center">
                            <?php if ($equipement['image']): ?>
                            <img src="../assets/images/equipements/<?= htmlspecialchars($equipement['image']) ?>" 
                                 alt="<?= htmlspecialchars($equipement['nom']) ?>" 
                                 class="img-fluid mb-3" style="max-height: 200px;">
                            <?php endif; ?>
                            
                            <h5><?= htmlspecialchars($equipement['nom']) ?></h5>
                            <p><?= nl2br(htmlspecialchars($equipement['description'])) ?></p>
                            
                            <a href="modifier.php?id=<?= $equipement['id_equi'] ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-edit"></i> Modifier
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
