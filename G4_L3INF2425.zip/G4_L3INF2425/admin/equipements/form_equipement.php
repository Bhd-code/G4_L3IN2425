<?php
require_once __DIR__ . '/../includes/auth.php';

$isEdit = isset($_GET['id']);
$page_title = $isEdit ? "Modifier un équipement" : "Ajouter un équipement";

// Initialisation des données
$equipement = [
    'id_equi' => null,
    'nom' => '',
    'description' => '',
    'image' => null,
    'numero_chambre' => null
];

$chambres = $db->query("
    SELECT c.numero, b.nom_batiment 
    FROM chambre c
    JOIN batiment b ON c.id_bat = b.id_bat
    ORDER BY b.nom_batiment, c.numero
")->fetchAll();

// Chargement des données existantes
if ($isEdit) {
    $id = (int)$_GET['id'];
    $stmt = $db->prepare("SELECT * FROM equipement WHERE id_equi = ?");
    $stmt->execute([$id]);
    $equipement = $stmt->fetch();

    if (!$equipement) {
        header("Location: index.php");
        exit();
    }
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérification CSRF si tu as cette fonction
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        die("Accès interdit");
    }

    $data = [
        'nom' => trim($_POST['nom']),
        'description' => trim($_POST['description']),
        'numero_chambre' => !empty($_POST['numero_chambre']) ? (int)$_POST['numero_chambre'] : null
    ];

    $uploadDir = __DIR__ . '/../../assets/images/equipements/';

    try {
        // Gestion suppression image existante si demandé
        if ($isEdit && !empty($_POST['remove_image']) && $equipement['image']) {
            $oldImage = $uploadDir . $equipement['image'];
            if (file_exists($oldImage)) {
                unlink($oldImage);
            }
            $data['image'] = null;
        } else {
            $data['image'] = $equipement['image'] ?? null;
        }

        // Gestion upload nouvelle image
        if (!empty($_FILES['image']['name'])) {
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            // Valider extension image
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (!in_array($extension, $allowed)) {
                throw new Exception("Format d'image non supporté.");
            }

            $filename = uniqid('', true) . '.' . $extension;
            $targetPath = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                // Supprimer ancienne image si elle existe
                if ($isEdit && $equipement['image']) {
                    $oldImage = $uploadDir . $equipement['image'];
                    if (file_exists($oldImage)) {
                        unlink($oldImage);
                    }
                }
                $data['image'] = $filename;
            } else {
                throw new Exception("Erreur lors de l'upload de l'image.");
            }
        }

        if ($isEdit) {
            // Mise à jour
            $data['id_equi'] = $equipement['id_equi'];
            $stmt = $db->prepare("
                UPDATE equipement 
                SET nom = ?, description = ?, image = ?, numero_chambre = ?
                WHERE id_equi = ?
            ");
            $stmt->execute([
                $data['nom'], $data['description'], $data['image'], $data['numero_chambre'], $data['id_equi']
            ]);
            $_SESSION['flash_success'] = "Équipement mis à jour avec succès";
        } else {
            // Insertion
            $stmt = $db->prepare("
                INSERT INTO equipement (nom, description, image, numero_chambre)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $data['nom'], $data['description'], $data['image'], $data['numero_chambre']
            ]);
            $_SESSION['flash_success'] = "Équipement ajouté avec succès";
        }

        header("Location: index.php");
        exit();
    } catch (Exception $e) {
        $_SESSION['flash_error'] = "Erreur: " . $e->getMessage();
    }
}
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?= $page_title ?></h1>
            </div>

            <?php if (isset($_SESSION['flash_error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['flash_error'] ?></div>
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>

            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom *</label>
                            <input type="text" class="form-control" id="nom" name="nom" 
                                   value="<?= htmlspecialchars($equipement['nom']) ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4"><?= htmlspecialchars($equipement['description']) ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="numero_chambre" class="form-label">Chambre associée</label>
                            <select class="form-select" id="numero_chambre" name="numero_chambre">
                                <option value="">Non affecté</option>
                                <?php foreach ($chambres as $chambre): ?>
                                <option value="<?= $chambre['numero'] ?>" 
                                    <?= $chambre['numero'] == $equipement['numero_chambre'] ? 'selected' : '' ?>>
                                    Ch. <?= $chambre['numero'] ?> - <?= htmlspecialchars($chambre['nom_batiment']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                            
                            <?php if ($isEdit && $equipement['image']): ?>
                            <div class="mt-3">
                                <p>Image actuelle :</p>
                                <img src="../assets/images/equipements/<?= htmlspecialchars($equipement['image']) ?>" 
                                     alt="<?= htmlspecialchars($equipement['nom']) ?>" 
                                     style="max-width: 200px; max-height: 200px;" class="img-thumbnail">
                                <div class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" id="remove_image" name="remove_image" value="1">
                                    <label class="form-check-label" for="remove_image">
                                        Supprimer cette image
                                    </label>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Enregistrer
                    </button>
                    <a href="index.php" class="btn btn-secondary">Annuler</a>
                </div>
            </form>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
