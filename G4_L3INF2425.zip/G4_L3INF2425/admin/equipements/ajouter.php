<?php
$page_title = "Ajouter un équipement";
require_once __DIR__ . '/../includes/auth.php';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'nom' => trim($_POST['nom']),
        'description' => trim($_POST['description']),
        'numero_chambre' => !empty($_POST['numero_chambre']) ? (int)$_POST['numero_chambre'] : null
    ];

    // Gestion de l'upload d'image
    $uploadDir = __DIR__ . '/../../assets/images/equipements/';
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    $maxSize = 2 * 1024 * 1024; // 2MB

    if (!empty($_FILES['image']['name'])) {
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($fileInfo, $_FILES['image']['tmp_name']);
        finfo_close($fileInfo);

        if (!in_array($mimeType, $allowedTypes)) {
            $_SESSION['flash_error'] = "Type de fichier non autorisé (seuls JPEG, PNG et WebP sont acceptés)";
        } elseif ($_FILES['image']['size'] > $maxSize) {
            $_SESSION['flash_error'] = "L'image est trop volumineuse (max 2MB)";
        } else {
            $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = uniqid('eq_', true) . '.' . $extension;
            $destination = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                $data['image'] = $filename;
            } else {
                $_SESSION['flash_error'] = "Erreur lors de l'upload de l'image";
            }
        }
    }

    // S'assurer qu'il n'y a pas d'erreur avant d'insérer
    if (!isset($_SESSION['flash_error'])) {
        try {
            $stmt = $db->prepare("
                INSERT INTO equipement (nom, description, numero_chambre, image)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $data['nom'],
                $data['description'],
                $data['numero_chambre'],
                $data['image'] ?? null
            ]);

            $_SESSION['flash_success'] = "Équipement ajouté avec succès";
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            // Supprimer l'image uploadée en cas d'erreur
            if (isset($data['image'])) {
                @unlink($uploadDir . $data['image']);
            }
            $_SESSION['flash_error'] = "Erreur: " . $e->getMessage();
        }
    }
}

// Liste des chambres disponibles
$chambres = $db->query("
    SELECT c.numero, b.nom_batiment 
    FROM chambre c
    JOIN batiment b ON c.id_bat = b.id_bat
    ORDER BY b.nom_batiment, c.numero
")->fetchAll();
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Ajouter un équipement</h1>
            </div>

            <?php if (isset($_SESSION['flash_error'])): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['flash_error']) ?></div>
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>

            <form method="post" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom *</label>
                            <input type="text" class="form-control" id="nom" name="nom" required value="<?= isset($data['nom']) ? htmlspecialchars($data['nom']) : '' ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?= isset($data['description']) ? htmlspecialchars($data['description']) : '' ?></textarea>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="numero_chambre" class="form-label">Affecter à une chambre</label>
                            <select class="form-select" id="numero_chambre" name="numero_chambre">
                                <option value="">Non affecté</option>
                                <?php foreach ($chambres as $ch): ?>
                                <option value="<?= $ch['numero'] ?>" <?= (isset($data['numero_chambre']) && $data['numero_chambre'] == $ch['numero']) ? 'selected' : '' ?>>
                                    Ch. <?= $ch['numero'] ?> - <?= htmlspecialchars($ch['nom_batiment']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/jpeg,image/png,image/webp">
                            <small class="text-muted">Formats acceptés: JPEG, PNG, WebP (max 2MB)</small>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Enregistrer
                    </button>
                    <a href="index.php" class="btn btn-secondary">Annuler</a>
                </div>
            </form>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
