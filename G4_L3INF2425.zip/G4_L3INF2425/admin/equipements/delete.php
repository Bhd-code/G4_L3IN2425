<?php
require_once __DIR__ . '/../includes/auth.php';

// Vérification CSRF
if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    die("Accès interdit");
}

$id = (int)$_POST['id'];

try {
    // Préparer la requête pour récupérer l'image
    $stmt = $db->prepare("SELECT image FROM equipement WHERE id_equi = ?");
    $stmt->execute([$id]);
    $equipement = $stmt->fetch();

    // Début de la transaction
    $db->beginTransaction();

    // Suppression des commentaires associés
    $stmt = $db->prepare("DELETE FROM commentaire WHERE id_equi = ?");
    $stmt->execute([$id]);

    // Suppression de l'équipement
    $stmt = $db->prepare("DELETE FROM equipement WHERE id_equi = ?");
    $stmt->execute([$id]);

    // Commit de la transaction
    $db->commit();

    // Suppression du fichier image si existant
    if ($equipement && !empty($equipement['image'])) {
        $imagePath = __DIR__ . '/../../assets/images/equipements/' . $equipement['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }

    $_SESSION['flash_success'] = "Équipement supprimé avec succès";
} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    $_SESSION['flash_error'] = "Erreur lors de la suppression : " . $e->getMessage();
}

header("Location: index.php");
exit();
