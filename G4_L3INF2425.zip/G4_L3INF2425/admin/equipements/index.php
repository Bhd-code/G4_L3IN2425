<?php
$page_title = "Gestion des équipements";
require_once __DIR__ . '/../includes/auth.php';

// Récupérer les équipements avec leurs chambres et le nombre de commentaires
$equipements = $db->query("
    SELECT e.*, c.numero AS chambre_numero, b.nom_batiment,
           (SELECT COUNT(*) FROM commentaire WHERE id_equi = e.id_equi) AS comment_count
    FROM equipement e
    LEFT JOIN chambre c ON e.numero_chambre = c.numero
    LEFT JOIN batiment b ON c.id_bat = b.id_bat
    ORDER BY e.nom
")->fetchAll();
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Gestion des équipements</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="ajouter.php" class="btn btn-success">
                        <i class="fas fa-plus"></i> Ajouter un équipement
                    </a>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Image</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Localisation</th>
                            <th>Commentaires</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($equipements as $eq): ?>
                        <tr>
                            <td>
                                <?php if ($eq['image']): ?>
                                <img src="../assets/images/equipements/<?= htmlspecialchars($eq['image']) ?>" 
                                     alt="<?= htmlspecialchars($eq['nom']) ?>" 
                                     style="width: 80px; height: 80px; object-fit: cover;">
                                <?php else: ?>
                                <div class="bg-secondary text-white d-flex align-items-center justify-content-center" 
                                     style="width: 80px; height: 80px;">
                                    <i class="fas fa-image fa-lg"></i>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($eq['nom']) ?></td>
                            <td><?= nl2br(htmlspecialchars(substr($eq['description'], 0, 100))) ?><?= strlen($eq['description']) > 100 ? '...' : '' ?></td>
                            <td>
                                <?php if ($eq['numero_chambre']): ?>
                                Ch. <?= $eq['chambre_numero'] ?>
                                <small class="d-block text-muted"><?= htmlspecialchars($eq['nom_batiment']) ?></small>
                                <?php else: ?>
                                <span class="text-muted">Non affecté</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?= $eq['comment_count'] > 0 ? 'primary' : 'secondary' ?>">
                                    <?= $eq['comment_count'] ?> commentaire(s)
                                </span>
                            </td>
                            <td>
                                <a href="modifier.php?id=<?= $eq['id_equi'] ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-sm btn-danger" 
                                        onclick="confirmDelete(<?= $eq['id_equi'] ?>, '<?= htmlspecialchars(addslashes($eq['nom'])) ?>')">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Formulaire de suppression caché -->
            <form id="deleteForm" method="post" action="delete.php">
                <input type="hidden" name="id" id="deleteId">
                <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
            </form>
        </main>
    </div>
</div>

<script>
function confirmDelete(id, name) {
    Swal.fire({
        title: 'Confirmer la suppression',
        html: `Voulez-vous vraiment supprimer l'équipement <b>${name}</b> ?<br>Tous les commentaires associés seront également supprimés.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Oui, supprimer',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
