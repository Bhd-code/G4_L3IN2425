<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

$errors = [];
$success = '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Récupération des étudiants
$etudiants = $db->query("SELECT matricule, nom FROM etudiant")->fetchAll();

// Vérifier que la réservation existe
$stmt = $db->prepare("SELECT * FROM reservation WHERE id_reser = ?");
$stmt->execute([$id]);
$reservation = $stmt->fetch();

if (!$reservation) {
    die("Réservation introuvable.");
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date_reservation = $_POST['date_reservation'] ?? '';
    $type_payement = trim($_POST['type_payement'] ?? '');
    $matricule_etudiant = trim($_POST['matricule_etudiant'] ?? '');
    $numero_chambre = filter_input(INPUT_POST, 'numero_chambre', FILTER_VALIDATE_INT);

    if (empty($date_reservation)) $errors[] = "La date de réservation est obligatoire.";
    if (empty($type_payement)) $errors[] = "Le type de paiement est obligatoire.";
    if (empty($matricule_etudiant)) $errors[] = "Le matricule de l'étudiant est obligatoire.";
    if (!$numero_chambre || $numero_chambre <= 0) $errors[] = "Le numéro de chambre est invalide.";

    // Vérifier si l'étudiant existe
    $check = $db->prepare("SELECT 1 FROM etudiant WHERE matricule = ?");
    $check->execute([$matricule_etudiant]);
    if (!$check->fetch()) {
        $errors[] = "Aucun étudiant trouvé avec ce matricule.";
    }

    // Mise à jour si tout est bon
    if (empty($errors)) {
        $stmt = $db->prepare("UPDATE reservation SET date_reservation = ?, type_payement = ?, matricule_etudiant = ?, numero_chambre = ? WHERE id_reser = ?");
        $stmt->execute([$date_reservation, $type_payement, $matricule_etudiant, $numero_chambre, $id]);
        header("Location: gestion_reservation.php"); // ✅ Redirection corrigée
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier réservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../img/img2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
        }

        .overlay {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 2rem;
            border-radius: 12px;
            margin-top: 4rem;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }

        .form-card {
            background-color: rgba(255, 255, 255, 0.93);
        }
    </style>
</head>
<body>

<div class="container">
    <div class="overlay">
        <h2>Modifier la réservation</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" class="card p-4 shadow-sm form-card">
            <div class="mb-3">
                <label class="form-label">Date de réservation *</label>
                <input type="date" name="date_reservation" class="form-control" required value="<?= htmlspecialchars($reservation['date_reservation']) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Type de paiement *</label>
                <select name="type_payement" class="form-control" required>
                    <option value="Espèce" <?= $reservation['type_payement'] === 'Espèce' ? 'selected' : '' ?>>Espèce</option>
                    <option value="Mobile Money" <?= $reservation['type_payement'] === 'Mobile Money' ? 'selected' : '' ?>>Mobile Money</option>
                    <option value="Virement" <?= $reservation['type_payement'] === 'Virement' ? 'selected' : '' ?>>Virement</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Matricule étudiant *</label>
                <select name="matricule_etudiant" class="form-control" required>
                    <?php foreach ($etudiants as $e): ?>
                        <option value="<?= $e['matricule'] ?>" <?= $reservation['matricule_etudiant'] === $e['matricule'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($e['matricule']) ?> - <?= htmlspecialchars($e['nom']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Numéro de chambre *</label>
                <input type="number" name="numero_chambre" class="form-control" required min="1" value="<?= htmlspecialchars($reservation['numero_chambre']) ?>">
            </div>

            <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
            <a href="gestion_reservation.php" class="btn btn-secondary ms-2">Annuler</a>
        </form>
    </div>
</div>

</body>
</html>
