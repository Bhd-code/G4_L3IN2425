<?php
session_start();

try {
    $db = new PDO('mysql:host=localhost;dbname=reservation_cite_universitaire;charset=utf8', 'root', '');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

$errors = [];
$success = '';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    die("ID de chambre invalide.");
}

// Récupérer les données actuelles de la chambre
$stmt = $db->prepare("SELECT * FROM chambre WHERE numero = ?");
$stmt->execute([$id]);
$chambre = $stmt->fetch();

if (!$chambre) {
    die("Chambre introuvable.");
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = trim($_POST['type'] ?? '');
    $disponibilite = trim($_POST['disponibilite'] ?? '');
    $prix = filter_input(INPUT_POST, 'prix', FILTER_VALIDATE_FLOAT);
    $id_bat = filter_input(INPUT_POST, 'id_bat', FILTER_VALIDATE_INT);
    $numero_ch = filter_input(INPUT_POST, 'numero_ch', FILTER_VALIDATE_INT);

    if (empty($type)) {
        $errors[] = "Le type de chambre est obligatoire.";
    }

    if ($disponibilite !== 'oui' && $disponibilite !== 'non') {
        $errors[] = "La disponibilité doit être 'oui' ou 'non'.";
    }

    if ($prix === false || $prix <= 0) {
        $errors[] = "Le prix doit être un nombre positif.";
    }

    if (!$id_bat || $id_bat <= 0) {
        $errors[] = "L'ID du bâtiment est invalide.";
    }

    if (!$numero_ch || $numero_ch <= 0) {
        $errors[] = "Le numéro de chambre doit être un entier positif.";
    }

    if (empty($errors)) {
        try {
            $stmt = $db->prepare("UPDATE chambre SET type = ?, disponibilite = ?, prix = ?, id_bat = ?, numero_ch = ? WHERE numero = ?");
            $stmt->execute([$type, $disponibilite, $prix, $id_bat, $numero_ch, $id]);

            // Redirection vers gestion_chambres.php après succès
            header('Location: gestion_chambres.php');
            exit;
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la modification : " . $e->getMessage();
        }
    }
} else {
    // Pré-remplir le formulaire avec les données existantes
    $type = $chambre['type'];
    $disponibilite = $chambre['disponibilite'];
    $prix = $chambre['prix'];
    $id_bat = $chambre['id_bat'];
    $numero_ch = $chambre['numero_ch'];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier Chambre</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../img/img2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0; padding: 0;
        }
        .overlay {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 2rem;
            border-radius: 12px;
            max-width: 600px;
            margin: 4rem auto;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }
        .btn-home {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #0d6efd;
            color: white;
            font-weight: bold;
            border-radius: 30px;
            padding: 0.5rem 1rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            text-decoration: none;
        }
    </style>
</head>
<body>

<a href="gestion_chambres.php" class="btn-home">🏠 Retour</a>

<div class="overlay">
    <h2 class="mb-4">Modifier la chambre #<?= htmlspecialchars($id) ?></h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Type de chambre *</label>
            <input type="text" name="type" class="form-control" required value="<?= htmlspecialchars($type) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Disponibilité *</label>
            <select name="disponibilite" class="form-select" required>
                <option value="">Choisir...</option>
                <option value="oui" <?= $disponibilite === 'oui' ? 'selected' : '' ?>>Oui</option>
                <option value="non" <?= $disponibilite === 'non' ? 'selected' : '' ?>>Non</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Prix *</label>
            <input type="number" step="0.01" name="prix" class="form-control" required min="0.01" value="<?= htmlspecialchars($prix) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">ID Bâtiment *</label>
            <input type="number" name="id_bat" class="form-control" required min="1" value="<?= htmlspecialchars($id_bat) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Numéro de chambre *</label>
            <input type="number" name="numero_ch" class="form-control" required min="1" value="<?= htmlspecialchars($numero_ch) ?>">
        </div>

        <button type="submit" class="btn btn-primary">Modifier</button>
    </form>
</div>

</body>
</html>
