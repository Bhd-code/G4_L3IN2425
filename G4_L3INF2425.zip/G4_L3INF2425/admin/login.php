<?php
session_start(); 
require_once __DIR__ . '/includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = secure_input($_POST['matricule']);
    $password = secure_input($_POST['password']);

    if ($username === ADMIN_USERNAME && $password === password) {
        $_SESSION['admin'] = ['matricule'=> $username];
        header('Location: inde2.php');
        exit();
    } else {
        $error = "Identifiants incorrects";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: url('../img/img1.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .overlay {
            background-color: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(2px);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

       .login-box {
        width: 100%;
        max-width: 400px;
        padding: 2rem;
        background: rgba(255, 255, 255, 0.95); /* blanc quasi opaque */
        border-radius: 12px;
        box-shadow: 0 0 20px rgba(0,0,0,0.15);
    }

        .login-box h2 {
            margin-bottom: 1.5rem;
            text-align: center;
            font-weight: bold;
            color: #343a40;
        }

        .alert {
            margin-bottom: 1rem;
        }

        .form-control {
            border-radius: 8px;
        }

        .btn-primary {
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="login-box">
            <h2>Espace Administrateur</h2>

            <?php if (isset($error)) : ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="mb-3">
                    <label for="username" class="form-label">Matricule</label>
                    <input type="text" class="form-control" id="username" name="matricule" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Mot de passe</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Se connecter</button>
            </form>
        </div>
    </div>
</body>
</html>
