<?php
$page_title = "Modifier un bâtiment";
require_once __DIR__ . '/../includes/auth.php';

// Vérification de l'ID
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];

// Récupération des données actuelles
$stmt = $db->prepare("SELECT * FROM batiment WHERE id_bat = ?");
$stmt->execute([$id]);
$batiment = $stmt->fetch();

if (!$batiment) {
    header("Location: index.php");
    exit();
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_batiment = trim($_POST['nom_batiment'] ?? '');
    $section = $_POST['section'] ?? '';
    $statut = $_POST['statut'] ?? '';
    $nbre_ch = (int)($_POST['nbre_ch'] ?? 0);
    $adresse = trim($_POST['adresse'] ?? '');

    // Validation simple
    if ($nom_batiment === '') {
        $errors[] = "Le nom du bâtiment est obligatoire.";
    }
    if (!in_array($section, ['fille', 'garçon'], true)) {
        $errors[] = "Section invalide.";
    }
    if (!in_array($statut, ['étudiant', 'enseignant'], true)) {
        $errors[] = "Statut invalide.";
    }
    if ($nbre_ch < 1) {
        $errors[] = "Le nombre de chambres doit être au moins 1.";
    }

    if (empty($errors)) {
        $stmt = $db->prepare("
            UPDATE batiment 
            SET nom_batiment = ?, section = ?, statut = ?, nbre_ch = ?, adresse = ?
            WHERE id_bat = ?
        ");
        $stmt->execute([$nom_batiment, $section, $statut, $nbre_ch, $adresse, $id]);

        header("Location: index.php?success=1");
        exit();
    }
}
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Modifier le bâtiment #<?= (int)$batiment['id_bat'] ?></h1>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="nom_batiment" class="form-label">Nom du bâtiment *</label>
                            <input type="text" class="form-control" id="nom_batiment" name="nom_batiment" 
                                   value="<?= htmlspecialchars($_POST['nom_batiment'] ?? $batiment['nom_batiment']) ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="section" class="form-label">Section *</label>
                            <select class="form-select" id="section" name="section" required>
                                <option value="fille" <?= (($_POST['section'] ?? $batiment['section']) === 'fille') ? 'selected' : '' ?>>Fille</option>
                                <option value="garçon" <?= (($_POST['section'] ?? $batiment['section']) === 'garçon') ? 'selected' : '' ?>>Garçon</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="statut" class="form-label">Statut *</label>
                            <select class="form-select" id="statut" name="statut" required>
                                <option value="étudiant" <?= (($_POST['statut'] ?? $batiment['statut']) === 'étudiant') ? 'selected' : '' ?>>Étudiant</option>
                                <option value="enseignant" <?= (($_POST['statut'] ?? $batiment['statut']) === 'enseignant') ? 'selected' : '' ?>>Enseignant</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="nbre_ch" class="form-label">Nombre de chambres *</label>
                            <input type="number" class="form-control" id="nbre_ch" name="nbre_ch" 
                                   value="<?= (int)($_POST['nbre_ch'] ?? $batiment['nbre_ch']) ?>" min="1" required>
                        </div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="adresse" class="form-label">Adresse</label>
                    <textarea class="form-control" id="adresse" name="adresse" rows="2"><?= htmlspecialchars($_POST['adresse'] ?? $batiment['adresse'] ?? '') ?></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Enregistrer
                </button>
                <a href="index.php" class="btn btn-secondary">Annuler</a>
            </form>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
