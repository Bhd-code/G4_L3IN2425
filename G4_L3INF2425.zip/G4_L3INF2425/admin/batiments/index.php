<?php
$page_title = "Gestion des bâtiments";
require_once __DIR__ . '/../includes/config.php';

// Vérification des permissions (à adapter selon votre système)
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    exit("Accès interdit");
}

// Génération du token CSRF s'il n'existe pas
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Traitement de la suppression
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'], $_POST['csrf_token'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Erreur de sécurité: Token CSRF invalide");
    }

    $id = filter_input(INPUT_POST, 'delete_id', FILTER_VALIDATE_INT);
    if ($id === false || $id <= 0) {
        die("ID de bâtiment invalide");
    }

    try {
        // Vérification qu'il n'y a pas de chambres dans le bâtiment
        $stmt = $db->prepare("SELECT COUNT(*) FROM chambre WHERE id_bat = ?");
        $stmt->execute([$id]);
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            header("Location: .?error=has_rooms");
            exit();
        }

        // Suppression du bâtiment
        $stmt = $db->prepare("DELETE FROM batiment WHERE id_bat = ?");
        $stmt->execute([$id]);
        
        header("Location: .?success=1");
        exit();
    } catch (PDOException $e) {
        error_log("Erreur suppression bâtiment: " . $e->getMessage());
        header("Location: .?error=db_error");
        exit();
    }
}

// Récupération des bâtiments avec pagination
$limit = 20;
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, ['options' => ['default' => 1, 'min_range' => 1]]);
$offset = ($page - 1) * $limit;

try {
    // Requête pour les bâtiments
    $stmt = $db->prepare("SELECT * FROM batiment ORDER BY id_bat DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $batiments = $stmt->fetchAll();

    // Comptage total pour la pagination
    $total = $db->query("SELECT COUNT(*) FROM batiment")->fetchColumn();

    // Récupération du nombre de chambres par bâtiment
    $countsRaw = $db->query("SELECT id_bat, COUNT(*) AS nb_chambres FROM chambre GROUP BY id_bat")->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Erreur DB: " . $e->getMessage());
    die("Une erreur est survenue lors de la récupération des données");
}
?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Gestion des bâtiments</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="ajouter.php" class="btn btn-success">
                        <i class="fas fa-plus"></i> Ajouter un bâtiment
                    </a>
                </div>
            </div>

            <!-- Messages d'alerte -->
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success">Opération effectuée avec succès!</div>
            <?php endif; ?>
            
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    switch($_GET['error']) {
                        case 'has_rooms': 
                            echo "Impossible de supprimer: le bâtiment contient des chambres";
                            break;
                        case 'db_error':
                            echo "Erreur de base de données";
                            break;
                        default:
                            echo "Une erreur est survenue";
                    }
                    ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Section</th>
                            <th>Statut</th>
                            <th>Chambres</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($batiments)): ?>
                            <tr>
                                <td colspan="6" class="text-center">Aucun bâtiment trouvé</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($batiments as $batiment): ?>
                            <tr>
                                <td><?= (int)$batiment['id_bat'] ?></td>
                                <td><?= htmlspecialchars($batiment['nom_batiment']) ?></td>
                                <td><?= htmlspecialchars(ucfirst($batiment['section'])) ?></td>
                                <td>
                                    <span class="badge bg-<?= $batiment['statut'] === 'actif' ? 'success' : 'warning' ?>">
                                        <?= htmlspecialchars(ucfirst($batiment['statut'])) ?>
                                    </span>
                                </td>
                                <td><?= $countsRaw[$batiment['id_bat']] ?? 0 ?></td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <a href="modifier.php?id=<?= (int)$batiment['id_bat'] ?>" class="btn btn-sm btn-primary" title="Modifier">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <form method="post" class="d-inline" onsubmit="return confirm('Supprimer ce bâtiment ?');">
                                            <input type="hidden" name="delete_id" value="<?= (int)$batiment['id_bat'] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" title="Supprimer" <?= isset($countsRaw[$batiment['id_bat']]) ? 'disabled' : '' ?>>
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ($total > $limit): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $page - 1 ?>">Précédent</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= ceil($total / $limit); $i++): ?>
                            <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if ($page < ceil($total / $limit)): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $page + 1 ?>">Suivant</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>