<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../includes/admin_functions.php';
admin_only();

// Pagination sécurisée
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Données paginées
$stmt = $db->prepare("SELECT * FROM batiment LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$batiments = $stmt->fetchAll();

// Total pour la pagination
$total = $db->query("SELECT COUNT(*) FROM batiment")->fetchColumn();
?>

<?php include '../includes/admin_header.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Gestion des bâtiments</h2>
        <a href="ajouter.php" class="btn btn-success">
            <i class="fas fa-plus"></i> Ajouter
        </a>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success">Opération réussie !</div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Section</th>
                        <th>Statut</th>
                        <th>Chambres</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($batiments as $bat): ?>
                    <tr>
                        <td><?= $bat['id_bat'] ?></td>
                        <td><?= htmlspecialchars($bat['nom_batiment']) ?></td>
                        <td><?= ucfirst($bat['section']) ?></td>
                        <td><?= ucfirst($bat['statut']) ?></td>
                        <td><?= $bat['nbre_ch'] ?></td>
                        <td>
                            <a href="modifier.php?id=<?= $bat['id_bat'] ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button class="btn btn-sm btn-danger delete-btn" data-id="<?= $bat['id_bat'] ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <nav>
                <ul class="pagination">
                    <?php for ($i = 1; $i <= ceil($total / $limit); $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        if (confirm('Supprimer ce bâtiment ?')) {
            fetch('supprimer.php?id=' + this.dataset.id, { method: 'POST' })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        this.closest('tr').remove();
                    } else {
                        alert("Erreur lors de la suppression.");
                    }
                });
        }
    });
});
</script>

<?php include '../includes/admin_footer.php'; ?>
