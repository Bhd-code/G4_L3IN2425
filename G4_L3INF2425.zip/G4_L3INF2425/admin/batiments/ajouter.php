<?php
$page_title = "Ajouter un bâtiment";
require_once __DIR__ . '/../includes/auth.php';

$errors = [];
$data = [
    'nom_batiment' => '',
    'section' => '',
    'statut' => '',
    'nbre_ch' => '',
    'adresse' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['nom_batiment'] = trim($_POST['nom_batiment'] ?? '');
    $data['section'] = $_POST['section'] ?? '';
    $data['statut'] = $_POST['statut'] ?? '';
    $data['nbre_ch'] = (int)($_POST['nbre_ch'] ?? 0);
    $data['adresse'] = trim($_POST['adresse'] ?? '');

    // Validation simple
    if ($data['nom_batiment'] === '') {
        $errors[] = "Le nom du bâtiment est obligatoire.";
    }
    if (!in_array($data['section'], ['fille', 'garçon'], true)) {
        $errors[] = "Section invalide.";
    }
    if (!in_array($data['statut'], ['étudiant', 'enseignant'], true)) {
        $errors[] = "Statut invalide.";
    }
    if ($data['nbre_ch'] < 1) {
        $errors[] = "Le nombre de chambres doit être au moins 1.";
    }

    if (empty($errors)) {
        $stmt = $db->prepare("
            INSERT INTO batiment (nom_batiment, section, statut, nbre_ch, adresse, date_creation)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $data['nom_batiment'],
            $data['section'],
            $data['statut'],
            $data['nbre_ch'],
            $data['adresse'],
        ]);

        header("Location: index.php?success=1");
        exit();
    }
}
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Ajouter un bâtiment</h1>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="nom_batiment" class="form-label">Nom du bâtiment *</label>
                            <input type="text" class="form-control" id="nom_batiment" name="nom_batiment" 
                                   value="<?= htmlspecialchars($data['nom_batiment']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="section" class="form-label">Section *</label>
                            <select class="form-select" id="section" name="section" required>
                                <option value="fille" <?= $data['section'] === 'fille' ? 'selected' : '' ?>>Fille</option>
                                <option value="garçon" <?= $data['section'] === 'garçon' ? 'selected' : '' ?>>Garçon</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="statut" class="form-label">Statut *</label>
                            <select class="form-select" id="statut" name="statut" required>
                                <option value="étudiant" <?= $data['statut'] === 'étudiant' ? 'selected' : '' ?>>Étudiant</option>
                                <option value="enseignant" <?= $data['statut'] === 'enseignant' ? 'selected' : '' ?>>Enseignant</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="nbre_ch" class="form-label">Nombre de chambres *</label>
                            <input type="number" class="form-control" id="nbre_ch" name="nbre_ch" 
                                   value="<?= htmlspecialchars($data['nbre_ch']) ?>" min="1" required>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="adresse" class="form-label">Adresse</label>
                    <textarea class="form-control" id="adresse" name="adresse" rows="2"><?= htmlspecialchars($data['adresse']) ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Enregistrer
                </button>
                <a href="index.php" class="btn btn-secondary">Annuler</a>
            </form>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
