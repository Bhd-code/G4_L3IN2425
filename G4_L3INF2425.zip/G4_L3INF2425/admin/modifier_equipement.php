<?php
session_start();

try {
    $db = new PDO('mysql:host=localhost;dbname=reservation_cite_universitaire;charset=utf8', 'root', '');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

$errors = [];
$success = '';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID équipement invalide.");
}

$id = (int) $_GET['id'];

// Récupérer l'équipement existant
$stmt = $db->prepare("SELECT * FROM equipement WHERE id_equi = ?");
$stmt->execute([$id]);
$equipement = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$equipement) {
    die("Équipement non trouvé.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $numero_chambre = filter_input(INPUT_POST, 'numero_chambre', FILTER_VALIDATE_INT);

    // Gestion de l'image
    $imageName = $equipement['image']; // garder l'ancienne image par défaut
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        $tmpName = $_FILES['image']['tmp_name'];
        $originalName = basename($_FILES['image']['name']);
        $imageName = uniqid() . '_' . $originalName;
        $targetPath = $uploadDir . $imageName;

        $mimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array(mime_content_type($tmpName), $mimeTypes)) {
            $errors[] = "Le fichier doit être une image (jpg, png, gif, webp).";
        } else {
            if (!move_uploaded_file($tmpName, $targetPath)) {
                $errors[] = "Erreur lors du téléchargement de l'image.";
            }
        }
    }

    if (empty($nom)) {
        $errors[] = "Le nom de l'équipement est obligatoire.";
    }

    if (!$numero_chambre || $numero_chambre <= 0) {
        $errors[] = "Le numéro de chambre est invalide.";
    }

    if (empty($errors)) {
        try {
            $stmt = $db->prepare("UPDATE equipement SET nom = ?, description = ?, image = ?, numero_chambre = ? WHERE id_equi = ?");
            $stmt->execute([$nom, $description, $imageName, $numero_chambre, $id]);

            // Redirection après modification réussie
            header('Location: gestion_equipements.php');
            exit;

        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la modification : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier équipement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../img/img2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0; padding: 0;
        }
        .overlay {
            background-color: rgba(255, 255, 255, 0.88);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
            max-width: 600px;
            margin: 50px auto;
        }
        .btn-home {
            background-color: #0d6efd;
            color: white;
            font-weight: bold;
            border-radius: 30px;
            padding: 0.5rem 1rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            position: absolute;
            top: 20px;
            right: 20px;
            text-decoration: none;
        }
        .form-card {
            background-color: rgba(255, 255, 255, 0.93);
        }
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        img.img-preview {
            max-width: 150px;
            margin-bottom: 1rem;
            border-radius: 8px;
        }
    </style>
</head>
<body>
<a href="gestion_equipements.php" class="btn btn-home">🏠 Accueil</a>

<div class="overlay">
    <h2 class="mb-4">Modifier équipement</h2>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="card p-4 shadow-sm form-card">
        <div class="mb-3">
            <label class="form-label">Nom de l'équipement *</label>
            <input type="text" name="nom" class="form-control" required value="<?= htmlspecialchars($equipement['nom']) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($equipement['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Image actuelle</label><br>
            <?php if (!empty($equipement['image'])): ?>
                <img src="uploads/<?= htmlspecialchars($equipement['image']) ?>" alt="Image équipement" class="img-preview">
            <?php else: ?>
                Aucune image
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Changer l'image</label>
            <input type="file" name="image" accept="image/*" class="form-control">
            <small class="text-muted">Laissez vide pour conserver l'image actuelle.</small>
        </div>

        <div class="mb-3">
            <label class="form-label">Numéro de chambre *</label>
            <input type="number" name="numero_chambre" class="form-control" required value="<?= htmlspecialchars($equipement['numero_chambre']) ?>">
        </div>

        <button type="submit" class="btn btn-primary">Modifier</button>
    </form>
</div>

</body>
</html>
