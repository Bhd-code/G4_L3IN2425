<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

$errors = [];
$success = '';

// Suppression directe
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $db->prepare("DELETE FROM reservation WHERE id_reser = ?");
    $stmt->execute([$id]);
    header("Location: gestion_reservation.php");
    exit();
}

// Ajout d'une réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date_reservation = $_POST['date_reservation'] ?? '';
    $type_payement = trim($_POST['type_payement'] ?? '');
    $matricule_etudiant = trim($_POST['matricule_etudiant'] ?? '');
    $numero_chambre = filter_input(INPUT_POST, 'numero_chambre', FILTER_VALIDATE_INT);

    if (empty($date_reservation)) $errors[] = "La date de réservation est obligatoire.";
    if (empty($type_payement)) $errors[] = "Le type de paiement est obligatoire.";
    if (empty($matricule_etudiant)) $errors[] = "Le matricule de l'étudiant est obligatoire.";
    if (!$numero_chambre || $numero_chambre <= 0) $errors[] = "Le numéro de chambre est invalide.";

    if (empty($errors)) {
        $stmt = $db->prepare("INSERT INTO reservation (date_reservation, type_payement, matricule_etudiant, numero_chambre) VALUES (?, ?, ?, ?)");
        $stmt->execute([$date_reservation, $type_payement, $matricule_etudiant, $numero_chambre]);
        $success = "Réservation ajoutée avec succès.";
    }
}

$reservations = $db->query("SELECT * FROM reservation ORDER BY id_reser DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des réservations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../img/img2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
        }

        .overlay {
            background-color: rgba(255, 255, 255, 0.88); /* transparence */
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }

        .top-right {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .btn-home {
            background-color: #0d6efd;
            color: white;
            font-weight: bold;
            border-radius: 30px;
            padding: 0.5rem 1rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            transition: background-color 0.3s;
        }

        .btn-home:hover {
            background-color: #0b5ed7;
        }

        .form-card {
            background-color: rgba(255, 255, 255, 0.93); /* transparence pour le formulaire */
        }
    </style>
</head>
<body>

<!-- Bouton retour à l'accueil -->
<div class="top-right">
    <a href="inde2.php" class="btn btn-home">🏠 Accueil</a>
</div>

<div class="container py-5">
    <div class="overlay">

        <h2 class="mb-4">Ajouter une réservation</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <form method="post" class="card p-4 shadow-sm mb-5 form-card">
            <div class="mb-3">
                <label class="form-label">Date de réservation *</label>
                <input type="date" name="date_reservation" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Type de paiement *</label>
                <select name="type_payement" class="form-control" required>
                    <option value="">-- Choisissez --</option>
                    <option value="Espèce">Espèce</option>
                    <option value="Mobile Money">Mobile Money</option>
                    <option value="Virement">Virement</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Matricule étudiant *</label>
                <input type="text" name="matricule_etudiant" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Numéro de chambre *</label>
                <input type="number" name="numero_chambre" class="form-control" required min="1">
            </div>

            <button type="submit" class="btn btn-primary">Ajouter</button>
        </form>

        <h3 class="mb-3">Liste des réservations</h3>
        <table class="table table-bordered table-hover bg-white shadow-sm">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Type paiement</th>
                    <th>Matricule étudiant</th>
                    <th>Numéro chambre</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservations as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['id_reser']) ?></td>
                        <td><?= htmlspecialchars($r['date_reservation']) ?></td>
                        <td><?= htmlspecialchars($r['type_payement']) ?></td>
                        <td><?= htmlspecialchars($r['matricule_etudiant']) ?></td>
                        <td><?= htmlspecialchars($r['numero_chambre']) ?></td>
                        <td>
                            <a href="modifier_reservation.php?id=<?= $r['id_reser'] ?>" class="btn btn-warning btn-sm">Modifier</a>
                            <a href="?delete=<?= $r['id_reser'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Voulez-vous vraiment supprimer cette réservation ?')">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    </div>
</div>

</body>
</html>
