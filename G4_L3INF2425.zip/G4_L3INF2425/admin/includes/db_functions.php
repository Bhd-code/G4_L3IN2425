<?php
require_once 'config.php';

/**
 * Récupère les chambres disponibles avec filtres optionnels
 *
 * @param PDO $db
 * @param array $filters
 * @return array
 */
function get_available_rooms($db, $filters = []) {
    $sql = "SELECT c.*, b.nom_batiment, b.section 
            FROM chambre c
            JOIN batiment b ON c.id_bat = b.id_bat
            WHERE c.disponibilite = 'oui'";
    
    $params = [];

    // Application des filtres si définis
    if (!empty($filters['type'])) {
        $sql .= " AND c.type = ?";
        $params[] = $filters['type'];
    }

    if (!empty($filters['id_bat'])) {
        $sql .= " AND c.id_bat = ?";
        $params[] = $filters['id_bat'];
    }

    if (!empty($filters['max_price'])) {
        $sql .= " AND c.prix <= ?";
        $params[] = $filters['max_price'];
    }

    if (!empty($filters['section'])) {
        $sql .= " AND b.section = ?";
        $params[] = $filters['section'];
    }

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Récupère les équipements d'une chambre
 *
 * @param PDO $db
 * @param string|int $room_number
 * @return array
 */
function get_room_equipments($db, $room_number) {
    $stmt = $db->prepare("SELECT * FROM equipement WHERE numero_chambre = ?");
    $stmt->execute([$room_number]);
    return $stmt->fetchAll();
}

/**
 * Crée une nouvelle réservation
 *
 * @param PDO $db
 * @param string $matricule
 * @param int $room_number
 * @param string $payment_type
 * @return int|false
 */
function create_reservation($db, $matricule, $room_number, $payment_type) {
    try {
        $db->beginTransaction();

        // Insertion de la réservation
        $stmt = $db->prepare("INSERT INTO reservation (type_payement, matricule_etudiant, numero_chambre) 
                              VALUES (?, ?, ?)");
        $stmt->execute([$payment_type, $matricule, $room_number]);

        // Marquer la chambre comme non disponible
        $stmt = $db->prepare("UPDATE chambre SET disponibilite = 'non' WHERE numero = ?");
        $stmt->execute([$room_number]);

        $db->commit();
        return $db->lastInsertId();
    } catch (PDOException $e) {
        $db->rollBack();
        error_log("Erreur de réservation : " . $e->getMessage());
        return false;
    }
}

/**
 * Annule une réservation et remet la chambre à disposition
 *
 * @param PDO $db
 * @param int $reservation_id
 * @param string $matricule
 * @return bool
 */
function cancel_reservation($db, $reservation_id, $matricule) {
    try {
        $db->beginTransaction();

        // Vérification de la réservation
        $stmt = $db->prepare("SELECT numero_chambre FROM reservation WHERE id_reser = ? AND matricule_etudiant = ?");
        $stmt->execute([$reservation_id, $matricule]);
        $reservation = $stmt->fetch();

        if (!$reservation) {
            $db->rollBack();
            return false;
        }

        // Suppression de la réservation
        $stmt = $db->prepare("DELETE FROM reservation WHERE id_reser = ?");
        $stmt->execute([$reservation_id]);

        // Mise à jour de la disponibilité de la chambre
        $stmt = $db->prepare("UPDATE chambre SET disponibilite = 'oui' WHERE numero = ?");
        $stmt->execute([$reservation['numero_chambre']]);

        $db->commit();
        return true;
    } catch (PDOException $e) {
        $db->rollBack();
        error_log("Erreur d'annulation : " . $e->getMessage());
        return false;
    }
}
?>
