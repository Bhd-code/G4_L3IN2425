<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column text-white">
            <li class="nav-item">
                <a class="nav-link <?= $current_page === 'index.php' ? 'active text-white' : 'text-light' ?>" href="../admin/">
                    <i class="fas fa-tachometer-alt me-2"></i>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'batiments') !== false ? 'active text-white' : 'text-light' ?>" href="../admin/batiments/">
                    <i class="fas fa-building me-2"></i>
                    Bâtiments
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'chambres') !== false ? 'active text-white' : 'text-light' ?>" href="../admin/chambres/">
                    <i class="fas fa-bed me-2"></i>
                    Chambres
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'utilisateurs') !== false ? 'active text-white' : 'text-light' ?>" href="../admin/utilisateurs/">
                    <i class="fas fa-users me-2"></i>
                    Utilisateurs
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'reservations') !== false ? 'active text-white' : 'text-light' ?>" href="../admin/reservations/">
                    <i class="fas fa-calendar-check me-2"></i>
                    Réservations
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page === 'stats.php' ? 'active text-white' : 'text-light' ?>" href="../admin/stats.php">
                    <i class="fas fa-chart-bar me-2"></i>
                    Statistiques
                </a>
            </li>
            <li class="nav-item mt-3">
                <a class="nav-link text-light" href="../logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i>
                    Déconnexion
                </a>
            </li>
        </ul>
    </div>
</div>
