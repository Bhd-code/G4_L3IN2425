<?php
// auth.php - Contrôle d'accès administrateur



// 2. Inclusion des dépendances
require_once __DIR__ . 'config.php';
require_once __DIR__ . 'functions.php';

// 3. Vérification de la connexion
if (!is_logged_in()) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'] ?? '/admin';
    header("Location: login.php");
    exit();
}

// 4. Vérification des privilèges admin
try {
    $stmt = $db->prepare("SELECT * FROM etudiant WHERE matricule = ? AND is_admin = 1 LIMIT 1");
    $stmt->execute([$_SESSION['admin']['matricule'] ?? null]);
    $admin_data = $stmt->fetch();

    if (!$admin_data) {
        $_SESSION['error'] = "Accès réservé aux administrateurs";
        header("Location: index.php");
        exit();
    }

    // 5. Mise à jour de la dernière activité
    $db->prepare("UPDATE etudiant SET last_login = NOW() WHERE matricule = ?")
       ->execute([$_SESSION['admin']['matricule']]);

    // 6. Définition des constantes admin
    define('ADMIN_THEME', 'dark'); // Options: 'light' ou 'dark'
    define('ADMIN_ACCESS_GRANTED', true);

} catch (PDOException $e) {
    error_log("Admin auth error: " . $e->getMessage());
    $_SESSION['error'] = "Erreur système";
    header("Location: login.php");
    exit();
}