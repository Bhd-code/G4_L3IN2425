<?php
$page_title = "Gestion des utilisateurs";
require_once __DIR__ . '/../includes/auth.php';

// Pagination
$perPage = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $perPage;

// Recherche et filtres
$search = $_GET['search'] ?? '';
$filters = [
    'faculte' => $_GET['faculte'] ?? null,
    'sexe' => $_GET['sexe'] ?? null
];

// Construction sécurisée des requêtes
$where = " WHERE 1=1";
$params = [];

if (!empty($search)) {
    $where .= " AND (nom LIKE ? OR prenom LIKE ? OR email LIKE ? OR matricule LIKE ?)";
    $searchTerm = "%$search%";
    array_push($params, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
}

$allowedFilters = ['faculte', 'sexe'];
foreach ($filters as $key => $value) {
    if (in_array($key, $allowedFilters) && !empty($value)) {
        $where .= " AND $key = ?";
        $params[] = $value;
    }
}

$query = "SELECT * FROM etudiant" . $where . " ORDER BY nom ASC LIMIT $perPage OFFSET $offset";
$countQuery = "SELECT COUNT(*) FROM etudiant" . $where;

$utilisateurs = $db->prepare($query)->execute($params)->fetchAll();
$total = $db->prepare($countQuery)->execute($params)->fetchColumn();
$totalPages = ceil($total / $perPage);

// Facultés disponibles
$facultes = $db->query("SELECT DISTINCT faculte FROM etudiant WHERE faculte IS NOT NULL ORDER BY faculte")->fetchAll(PDO::FETCH_COLUMN);
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Gestion des utilisateurs</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="ajouter.php" class="btn btn-success">
                        <i class="fas fa-user-plus"></i> Ajouter
                    </a>
                </div>
            </div>

            <!-- Recherche et filtres -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="get" class="row g-3" autocomplete="off">
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="text" class="form-control" name="search" placeholder="Rechercher..." value="<?= htmlspecialchars($search) ?>">
                                <button class="btn btn-outline-secondary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" name="faculte">
                                <option value="">Toutes facultés</option>
                                <?php foreach ($facultes as $f): ?>
                                <option value="<?= htmlspecialchars($f) ?>" <?= $filters['faculte'] === $f ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($f) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" name="sexe">
                                <option value="">Tous genres</option>
                                <option value="Homme" <?= $filters['sexe'] === 'Homme' ? 'selected' : '' ?>>Homme</option>
                                <option value="Femme" <?= $filters['sexe'] === 'Femme' ? 'selected' : '' ?>>Femme</option>
                            </select>
                        </div>
                        <div class="col-md-1 d-grid">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i>
                            </button>
                        </div>
                        <div class="col-md-1 d-grid">
                            <a href="index.php" class="btn btn-outline-secondary">
                                <i class="fas fa-times"></i>
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tableau des utilisateurs -->
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Matricule</th>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Téléphone</th>
                            <th>Faculté</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($utilisateurs as $user): ?>
                        <tr>
                            <td><?= htmlspecialchars($user['matricule']) ?></td>
                            <td><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                            <td><?= htmlspecialchars($user['tel']) ?></td>
                            <td><?= htmlspecialchars($user['faculte']) ?></td>
                            <td>
                                <a href="modifier.php?matricule=<?= $user['matricule'] ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-sm btn-danger" 
                                        onclick="confirmDelete('<?= $user['matricule'] ?>', '<?= htmlspecialchars(addslashes($user['prenom'] . ' ' . $user['nom'])) ?>')">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php if (empty($utilisateurs)): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">Aucun utilisateur trouvé.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center mt-4">
                    <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">Précédent</a>
                    </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">Suivant</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- Formulaire de suppression -->
            <form id="deleteForm" method="post" action="delete.php">
                <input type="hidden" name="matricule" id="deleteMatricule">
                <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
            </form>
        </main>
    </div>
</div>

<script>
function confirmDelete(matricule, name) {
    Swal.fire({
        title: 'Confirmer la suppression',
        html: `Voulez-vous vraiment supprimer l'utilisateur <b>${name}</b> ?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Oui, supprimer',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('deleteMatricule').value = matricule;
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
