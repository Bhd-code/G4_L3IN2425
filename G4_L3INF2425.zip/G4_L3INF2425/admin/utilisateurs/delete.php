<?php
require_once __DIR__ . '/../includes/auth.php';

// Vérification CSRF
if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    die("Accès interdit");
}

$matricule = $_POST['matricule'];

try {
    // Vérifier les réservations actives
    $stmt = $db->prepare("SELECT COUNT(*) FROM reservation WHERE matricule_etudiant = ?");
    $stmt->execute([$matricule]);
    $reservations = $stmt->fetchColumn();

    if ($reservations > 0) {
        $_SESSION['flash_error'] = "Impossible de supprimer : l'utilisateur a des réservations actives.";
        header("Location: index.php");
        exit();
    }

    // Vérifier si c'est le dernier admin
    $stmt = $db->prepare("SELECT is_admin FROM etudiant WHERE matricule = ?");
    $stmt->execute([$matricule]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $user['is_admin']) {
        $adminCount = $db->query("SELECT COUNT(*) FROM etudiant WHERE is_admin = 1")->fetchColumn();
        if ($adminCount <= 1) {
            $_SESSION['flash_error'] = "Impossible de supprimer : c'est le dernier administrateur.";
            header("Location: index.php");
            exit();
        }
    }

    // Suppression
    $stmt = $db->prepare("DELETE FROM etudiant WHERE matricule = ?");
    $stmt->execute([$matricule]);

    $_SESSION['flash_success'] = "Utilisateur supprimé avec succès.";
} catch (PDOException $e) {
    $_SESSION['flash_error'] = "Erreur : " . $e->getMessage();
}

header("Location: index.php");
exit();
