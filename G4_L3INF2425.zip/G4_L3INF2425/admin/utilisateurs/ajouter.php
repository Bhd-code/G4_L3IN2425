<?php
$page_title = "Ajouter un utilisateur";
require_once __DIR__ . '/../includes/auth.php';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'matricule' => strtoupper(trim($_POST['matricule'])),
        'nom'       => trim($_POST['nom']),
        'prenom'    => trim($_POST['prenom']),
        'email'     => trim($_POST['email']),
        'tel'       => trim($_POST['tel']),
        'sexe'      => $_POST['sexe'],
        'faculte'   => $_POST['faculte'],
        'password'  => password_hash($_POST['password'], PASSWORD_DEFAULT),
        'is_admin'  => isset($_POST['is_admin']) ? 1 : 0
    ];

    try {
        // Vérification de l'existence du matricule
        $stmt = $db->prepare("SELECT COUNT(*) FROM etudiant WHERE matricule = ?");
        $stmt->execute([$data['matricule']]);
        $exists = $stmt->fetchColumn();

        if ($exists > 0) {
            throw new Exception("Ce matricule existe déjà");
        }

        // Insertion
        $stmt = $db->prepare("
            INSERT INTO etudiant 
            (matricule, nom, prenom, email, tel, sexe, faculte, password, is_admin)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute(array_values($data));

        $_SESSION['flash_success'] = "Utilisateur créé avec succès";
        header("Location: index.php");
        exit();
    } catch (Exception $e) {
        $_SESSION['flash_error'] = $e->getMessage();
    }
}

// Liste des facultés existantes
$facultes = $db->query("SELECT DISTINCT faculte FROM etudiant WHERE faculte IS NOT NULL ORDER BY faculte")->fetchAll(PDO::FETCH_COLUMN);
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Ajouter un utilisateur</h1>
            </div>

            <?php if (isset($_SESSION['flash_error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['flash_error'] ?></div>
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>

            <form method="post">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="matricule" class="form-label">Matricule *</label>
                            <input type="text" class="form-control" id="matricule" name="matricule" required
                                   pattern="[A-Za-z0-9]{6,20}" title="6 à 20 caractères alphanumériques">
                        </div>
                        
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom *</label>
                            <input type="text" class="form-control" id="nom" name="nom" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="prenom" class="form-label">Prénom *</label>
                            <input type="text" class="form-control" id="prenom" name="prenom" required>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email *</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="tel" class="form-label">Téléphone</label>
                            <input type="tel" class="form-control" id="tel" name="tel">
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Mot de passe *</label>
                            <input type="password" class="form-control" id="password" name="password" required
                                   minlength="8" pattern="^(?=.*[A-Za-z])(?=.*\d).{8,}$" 
                                   title="8 caractères minimum avec au moins une lettre et un chiffre">
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="sexe" class="form-label">Sexe</label>
                            <select class="form-select" id="sexe" name="sexe">
                                <option value="Homme">Homme</option>
                                <option value="Femme">Femme</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="faculte" class="form-label">Faculté</label>
                            <input type="text" class="form-control" id="faculte" name="faculte" list="facultes-list">
                            <datalist id="facultes-list">
                                <?php foreach ($facultes as $f): ?>
                                <option value="<?= htmlspecialchars($f) ?>"></option>
                                <?php endforeach; ?>
                            </datalist>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="is_admin" name="is_admin">
                            <label class="form-check-label" for="is_admin">Accès administrateur</label>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Enregistrer
                    </button>
                    <a href="index.php" class="btn btn-secondary">Annuler</a>
                </div>
            </form>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
