<?php
$page_title = "Modifier un utilisateur";
require_once __DIR__ . '/../includes/auth.php';

// Vérification du matricule
if (!isset($_GET['matricule'])) {
    header("Location: index.php");
    exit();
}

$matricule = $_GET['matricule'];

// Récupération des données utilisateur
$stmt = $db->prepare("SELECT * FROM etudiant WHERE matricule = ?");
$stmt->execute([$matricule]);
$user = $stmt->fetch();

if (!$user) {
    header("Location: index.php");
    exit();
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'nom'       => trim($_POST['nom']),
        'prenom'    => trim($_POST['prenom']),
        'email'     => trim($_POST['email']),
        'tel'       => trim($_POST['tel']),
        'sexe'      => $_POST['sexe'],
        'faculte'   => $_POST['faculte'],
        'is_admin'  => isset($_POST['is_admin']) ? 1 : 0
    ];

    try {
        if (!empty($_POST['password'])) {
            $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $sql = "UPDATE etudiant SET nom = ?, prenom = ?, email = ?, tel = ?, sexe = ?, faculte = ?, is_admin = ?, password = ? WHERE matricule = ?";
            $values = [...array_values($data), $matricule];
        } else {
            $sql = "UPDATE etudiant SET nom = ?, prenom = ?, email = ?, tel = ?, sexe = ?, faculte = ?, is_admin = ? WHERE matricule = ?";
            $values = [...array_values($data), $matricule];
        }

        $db->prepare($sql)->execute($values);
        $_SESSION['flash_success'] = "Utilisateur mis à jour avec succès.";
        header("Location: index.php");
        exit();
    } catch (Exception $e) {
        $_SESSION['flash_error'] = "Erreur lors de la mise à jour : " . $e->getMessage();
    }
}

// Récupération des facultés pour la datalist
$facultes = $db->query("SELECT DISTINCT faculte FROM etudiant WHERE faculte IS NOT NULL ORDER BY faculte")->fetchAll(PDO::FETCH_COLUMN);
?>

<?php include __DIR__ . '/../includes/head.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Modifier l'utilisateur</h1>
                <span class="badge bg-<?= $user['is_admin'] ? 'danger' : 'primary' ?>">
                    <?= $user['is_admin'] ? 'Administrateur' : 'Étudiant' ?>
                </span>
            </div>

            <?php if (isset($_SESSION['flash_error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['flash_error'] ?></div>
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>

            <form method="post">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Matricule</label>
                            <input type="text" class="form-control-plaintext" readonly value="<?= htmlspecialchars($user['matricule']) ?>">
                        </div>

                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom *</label>
                            <input type="text" class="form-control" id="nom" name="nom" required value="<?= htmlspecialchars($user['nom']) ?>">
                        </div>

                        <div class="mb-3">
                            <label for="prenom" class="form-label">Prénom *</label>
                            <input type="text" class="form-control" id="prenom" name="prenom" required value="<?= htmlspecialchars($user['prenom']) ?>">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email *</label>
                            <input type="email" class="form-control" id="email" name="email" required value="<?= htmlspecialchars($user['email']) ?>">
                        </div>

                        <div class="mb-3">
                            <label for="tel" class="form-label">Téléphone</label>
                            <input type="tel" class="form-control" id="tel" name="tel" value="<?= htmlspecialchars($user['tel']) ?>">
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Nouveau mot de passe</label>
                            <input type="password" class="form-control" id="password" name="password"
                                   minlength="8" pattern="^(?=.*[A-Za-z])(?=.*\d).{8,}$"
                                   title="8 caractères minimum avec au moins une lettre et un chiffre">
                            <small class="text-muted">Laisser vide pour ne pas modifier</small>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="sexe" class="form-label">Sexe</label>
                            <select class="form-select" id="sexe" name="sexe">
                                <option value="Homme" <?= $user['sexe'] === 'Homme' ? 'selected' : '' ?>>Homme</option>
                                <option value="Femme" <?= $user['sexe'] === 'Femme' ? 'selected' : '' ?>>Femme</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="faculte" class="form-label">Faculté</label>
                            <input type="text" class="form-control" id="faculte" name="faculte" list="facultes-list"
                                   value="<?= htmlspecialchars($user['faculte']) ?>">
                            <datalist id="facultes-list">
                                <?php foreach ($facultes as $f): ?>
                                    <option value="<?= htmlspecialchars($f) ?>"></option>
                                <?php endforeach; ?>
                            </datalist>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="mb-3 form-check mt-4 pt-2">
                            <input type="checkbox" class="form-check-input" id="is_admin" name="is_admin"
                                   <?= $user['is_admin'] ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_admin">Accès administrateur</label>
                        </div>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Enregistrer
                    </button>
                    <a href="index.php" class="btn btn-secondary">Annuler</a>
                </div>
            </form>
        </main>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
