<?php
session_start();
include '../includes/config.php';

if (isset($_SESSION['user']['sexe'])) {
    header("Location: index.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $matricule = secure_input($_POST['matricule']);
    $nom = secure_input($_POST['nom']);
    $prenom = secure_input($_POST['prenom']);
    $email = secure_input($_POST['email']);
    $tel = secure_input($_POST['tel']);
    $sexe = secure_input($_POST['sexe']);
    $password = password_hash(secure_input($_POST['password']), PASSWORD_DEFAULT);

    try {
        $stmt = $db->prepare("INSERT INTO etudiant (matricule, nom, prenom, email, tel, sexe, password) 
                             VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$matricule, $nom, $prenom, $email, $tel, $sexe, $password]);
        $_SESSION['user']=[
            "matricule" => $matricule,
            "nom" => $nom,
            "prenom" => $prenom,
            "sexe" =>$sexe,
            "email" =>$email 
        ];
        
        header("Location: dashboard.php");
        exit();
    } catch (PDOException $e) {
        $error = "Erreur d'inscription: " . htmlspecialchars($e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Inscription</title>
    <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
    <div class="register-container">
        <h2>Inscription</h2>

        <?php if ($error): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <form action="" method="post" novalidate>
            <div class="form-group">
                <label for="matricule">Matricule</label>
                <input type="text" id="matricule" name="matricule" required>
            </div>

            <div class="form-group">
                <label for="nom">Nom</label>
                <input type="text" id="nom" name="nom" required>
            </div>

            <div class="form-group">
                <label for="prenom">Prénom</label>
                <input type="text" id="prenom" name="prenom" required>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="tel">Téléphone</label>
                <input type="tel" id="tel" name="tel" required>
            </div>

            <div class="form-group">
                <label for="sexe">Sexe</label>
                <select id="sexe" name="sexe" required>
                    <option value="">-- Sélectionnez --</option>
                    <option value="H">Homme</option>
                    <option value="F">Femme</option>
                </select>
            </div>

            <div class="form-group">
                <label for="password">Mot de passe</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="btn">S'inscrire</button>
        </form>

        <p>Déjà un compte ? <a href="login.php">Se connecter</a></p>
    </div>
</body>
</html>
