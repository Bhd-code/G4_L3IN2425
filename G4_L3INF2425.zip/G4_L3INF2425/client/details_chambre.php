<?php 
session_start();
include '../includes/config.php';
include '../includes/functions.php';

$numero_chambre = filter_input(INPUT_GET, 'numero', FILTER_VALIDATE_INT);
if (!$numero_chambre) {
    header("Location: chambres.php");
    exit();
}

// Récupérer les détails de la chambre
$stmt = $db->prepare("SELECT * FROM chambre WHERE numero = ?");
$stmt->execute([$numero_chambre]);
$chambre = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$chambre) {
    header("Location: chambres.php");
    exit();
}

// Récupérer les équipements de la chambre
$stmt = $db->prepare("SELECT * FROM equipement WHERE numero_chambre = ?");
$stmt->execute([$numero_chambre]);
$equipements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Vérifier si l'utilisateur a déjà une réservation
$stmt = $db->prepare("SELECT * FROM reservation WHERE matricule_etudiant = ?");
$stmt->execute([$_SESSION['user']['matricule']]);
$has_reservation = $stmt->fetch();

// Récupérer tous les commentaires existants de l'utilisateur
$stmt = $db->prepare("SELECT id_equi, message FROM commentaire WHERE matricule_etudiant = ?");
$stmt->execute([$_SESSION['user']['matricule']]);
$commentaires_user = [];
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $c) {
    $commentaires_user[$c['id_equi']] = $c['message'];
}

// Traitement des commentaires
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['commentaire'])) {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        die('Erreur CSRF');
    }

    $id_equi = secure_input($_POST['id_equi']);
    $message = secure_input($_POST['commentaire']);

    $stmt = $db->prepare("SELECT * FROM commentaire WHERE id_equi = ? AND matricule_etudiant = ?");
    $stmt->execute([$id_equi, $_SESSION['matricule']]);
    $existing_comment = $stmt->fetch();

    if ($existing_comment) {
        $stmt = $db->prepare("UPDATE commentaire SET message = ? WHERE id_com = ?");
        $stmt->execute([$message, $existing_comment['id_com']]);
    } else {
        $stmt = $db->prepare("INSERT INTO commentaire (message, id_equi, matricule_etudiant) VALUES (?, ?, ?)");
        $stmt->execute([$message, $id_equi, $_SESSION['matricule']]);
    }

    header("Location: details_chambre.php?numero=$numero_chambre");
    exit();
}

// Récupérer tous les commentaires pour cette chambre
$stmt = $db->prepare("SELECT c.*, e.nom AS equipement_nom, et.nom AS etudiant_nom, et.prenom AS etudiant_prenom 
                      FROM commentaire c
                      JOIN equipement e ON c.id_equi = e.id_equi
                      JOIN etudiant et ON c.matricule_etudiant = et.matricule
                      WHERE e.numero_chambre = ?");
$stmt->execute([$numero_chambre]);
$commentaires = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails de la Chambre</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .equipement-image img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: .5rem;
        }
        .commentaire-card {
            border: 1px solid #ddd;
            border-radius: .5rem;
            padding: 1rem;
            margin-bottom: 1rem;
            background-color: #f8f9fa;
        }
        .commentaire-header {
            font-weight: bold;
            margin-bottom: .5rem;
        }
        .commentaire-actions a {
            margin-right: .5rem;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <h1 class="mb-4 text-center">Chambre N°<?= htmlspecialchars($chambre['numero']) ?></h1>

        <div class="row g-4 mb-5">
            <div class="col-md-6">
                <img src="../admin/uploads/chambre-<?= htmlspecialchars($chambre['type']) ?>.jpg" alt="Chambre" class="img-fluid rounded shadow">
            </div>
            <div class="col-md-6">
                <div class="card p-4 shadow-sm">
                    <h4 class="mb-3">Informations</h4>
                    <p><strong>Type:</strong> <?= ucfirst(htmlspecialchars($chambre['type'])) ?></p>
                    <p><strong>Prix:</strong> <?= htmlspecialchars($chambre['prix']) ?>$</p>
                    <p><strong>Bâtiment:</strong> <?= htmlspecialchars($chambre['id_bat']) ?></p>
                    <p><strong>Disponibilité:</strong> 
                        <?= $chambre['disponibilite'] === 'oui' ? '<span class="text-success">Disponible</span>' : '<span class="text-danger">Non disponible</span>' ?>
                    </p>
                    <?php if ($chambre['disponibilite'] === 'oui' && !$has_reservation): ?>
                        <a href="reservation.php?numero=<?= $chambre['numero'] ?>" class="btn btn-primary mt-3">Réserver cette chambre</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <h3 class="mb-4">Équipements</h3>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mb-5">
            <?php foreach ($equipements as $equipement): ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <div class="equipement-image">
                            <img src="../admin/uploads/<?= htmlspecialchars($equipement['image']) ?>" alt="<?= htmlspecialchars($equipement['nom']) ?>">
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($equipement['nom']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($equipement['description']) ?></p>
                            <form method="post">
                                <input type="hidden" name="id_equi" value="<?= $equipement['id_equi'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">

                                <div class="mb-2">
                                    <label for="commentaire-<?= $equipement['id_equi'] ?>" class="form-label">Votre commentaire :</label>
                                    <textarea id="commentaire-<?= $equipement['id_equi'] ?>" name="commentaire" rows="2" class="form-control"><?= htmlspecialchars($commentaires_user[$equipement['id_equi']] ?? '') ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-outline-primary btn-sm">Envoyer</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <h3 class="mb-4">Commentaires</h3>
        <?php if (empty($commentaires)): ?>
            <p class="text-muted">Aucun commentaire pour cette chambre.</p>
        <?php else: ?>
            <?php foreach ($commentaires as $commentaire): ?>
                <div class="commentaire-card">
                    <div class="commentaire-header">
                        <?= htmlspecialchars($commentaire['etudiant_prenom'] . ' ' . $commentaire['etudiant_nom']) ?>
                        <span class="text-muted"> sur <strong><?= htmlspecialchars($commentaire['equipement_nom']) ?></strong></span>
                        <div><small class="text-muted"><?= date('d/m/Y H:i', strtotime($commentaire['date_envoie'])) ?></small></div>
                    </div>
                    <div class="commentaire-body">
                        <p><?= htmlspecialchars($commentaire['message']) ?></p>
                    </div>
                    <?php if ($commentaire['matricule_etudiant'] === $_SESSION['matricule']): ?>
                        <div class="commentaire-actions mt-2">
                            <a href="modifier-commentaire.php?id=<?= $commentaire['id_com'] ?>" class="btn btn-sm btn-secondary">Modifier</a>
                            <a href="supprimer-commentaire.php?id=<?= $commentaire['id_com'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression ?')">Supprimer</a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
