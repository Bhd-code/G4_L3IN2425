<?php
function process_virement_payment($reference, $amount) {
    // Simulation : normalement, un appel à une API bancaire serait fait
    return strlen($reference) >= 5;
}
