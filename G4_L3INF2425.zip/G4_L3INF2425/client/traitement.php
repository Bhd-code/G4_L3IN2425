<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_SESSION['reservation_temp'])) {
    redirect_with_message('chambres.php', 'Session expirée. Veuillez recommencer.', 'danger');
}

$reservation = $_SESSION['reservation_temp'];
$type = $reservation['type_paiement'];
$payment_data = $reservation['payment_data'];

if ($type === 'paypal') {
     header("paypal_api.php");
    $success = process_paypal_payment($payment_data['email_paypal'], $reservation['montant']);
} elseif ($type === 'virement') {
     header("virement_api.php");
    $success = process_virement_payment($payment_data['reference_virement'], $reservation['montant']);
} else {
    redirect_with_message('chambres.php', 'Méthode de paiement non supportée', 'danger');
}

if ($success) {
    // Enregistrement en base (table reservation)
    $stmt = $db->prepare("INSERT INTO reservation (numero_chambre, matricule_etudiant, date_reservation, type_paiement) VALUES (?, ?, NOW(), ?)");
    $stmt->execute([$reservation['numero_chambre'], $_SESSION['user']['matricule'], $type]);

    // Mise à jour de la chambre
    $db->prepare("UPDATE chambre SET disponibilite = 'non' WHERE numero = ?")->execute([$reservation['numero_chambre']]);

    unset($_SESSION['reservation_temp']);
    redirect_with_message('chambres.php', 'Réservation effectuée avec succès !', 'success');
} else {
    redirect_with_message("reservation.php?numero=" . $reservation['numero_chambre'], "Échec du paiement. Réessayez.", 'danger');
}
