<?php 
session_start(); 
include '../includes/config.php';
include '../includes/functions.php';

if (!isset($_SESSION['user']) || !isset($_SESSION['user']['matricule'])) {
    header('Location: ../login.php');
    exit();
}

$student = get_student_info($db, $_SESSION['user']['matricule']);

$stmt = $db->prepare("SELECT * FROM reservation WHERE matricule_etudiant = ?");
$stmt->execute([$_SESSION['user']['matricule']]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $db->query("SELECT * FROM batiment");
$batiments = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $db->query("SELECT * FROM chambre WHERE disponibilite = 1");
$chambres = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Chambres Disponibles</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .chambre-image img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
        }
    </style>
</head>
<body>
<main class="container">
    <h1>Chambres Disponibles</h1>

    <div class="filter-section">
        <form id="filter-form">
            <div class="form-group">
                <label for="type">Type de chambre:</label>
                <select id="type" name="type">
                    <option value="all">Tous</option>
                    <option value="studio">Studio</option>
                    <option value="simple">Simple</option>
                </select>
            </div>

            <div class="form-group">
                <label for="batiment">Bâtiment:</label>
                <select id="batiment" name="batiment">
                    <option value="all">Tous</option>
                    <?php foreach ($batiments as $batiment): ?>
                        <option value="<?php echo htmlspecialchars($batiment['id_bat']); ?>">
                            Bâtiment <?php echo htmlspecialchars($batiment['id_bat']); ?> 
                            (<?php echo htmlspecialchars($batiment['section']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="prix">Prix maximum:</label>
                <input type="range" id="prix" name="prix" min="0" max="1000000" step="10" value="1000000">
                <span id="prix-value">1000000$</span>
            </div>

            <button type="button" id="filter-btn" class="btn">Filtrer</button>
        </form>
    </div>

    <div class="chambres-grid" id="chambres-container">
        <?php if (empty($chambres)): ?>
            <p class="no-rooms">Aucune chambre disponible pour le moment.</p>
        <?php else: ?>
            <?php foreach ($chambres as $chambre): ?>
                <div class="chambre-card" 
                     data-type="<?php echo htmlspecialchars($chambre['type']); ?>" 
                     data-batiment="<?php echo htmlspecialchars($chambre['id_bat']); ?>" 
                     data-prix="<?php echo htmlspecialchars($chambre['prix']); ?>">
                    <div class="chambre-image">
                        <?php if (!empty($chambre['img']) && file_exists("../uploads/chambres/" . $chambre['img'])): ?>
                            <img src="../uploads/chambres/<?php echo htmlspecialchars($chambre['img']); ?>" 
                                 alt="Chambre <?php echo htmlspecialchars($chambre['numero']); ?>">
                        <?php else: ?>
                            <img src="../assets/images/chambre-<?php echo htmlspecialchars($chambre['type']); ?>.jpg" 
                                 alt="Chambre <?php echo htmlspecialchars($chambre['type']); ?>">
                        <?php endif; ?>
                    </div>

                    <div class="chambre-info">
                        <h3>Chambre N°<?php echo htmlspecialchars($chambre['numero']); ?></h3>
                        <p><strong>Type:</strong> <?php echo ucfirst(htmlspecialchars($chambre['type'])); ?></p>
                        <p><strong>Prix:</strong> <?php echo htmlspecialchars($chambre['prix']); ?>$</p>
                        <p><strong>Bâtiment:</strong> <?php echo htmlspecialchars($chambre['id_bat']); ?></p>

                        <a href="details_chambre.php?numero=<?php echo htmlspecialchars($chambre['numero']); ?>" class="btn">Voir détails</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>

<script>
    document.getElementById('filter-btn').addEventListener('click', function () {
        const type = document.getElementById('type').value;
        const batiment = document.getElementById('batiment').value;
        const prix = parseFloat(document.getElementById('prix').value) || 0;

        document.querySelectorAll('.chambre-card').forEach(card => {
            const cardType = card.dataset.type;
            const cardBatiment = card.dataset.batiment;
            const cardPrix = parseFloat(card.dataset.prix) || 0;

            const typeMatch = type === 'all' || cardType === type;
            const batimentMatch = batiment === 'all' || cardBatiment === batiment;
            const prixMatch = cardPrix <= prix;

            card.style.display = (typeMatch && batimentMatch && prixMatch) ? 'block' : 'none';
        });
    });

    document.getElementById('prix').addEventListener('input', function () {
        document.getElementById('prix-value').textContent = this.value + '$';
    });

    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('filter-btn').click();
    });
</script>
</body>
</html>
