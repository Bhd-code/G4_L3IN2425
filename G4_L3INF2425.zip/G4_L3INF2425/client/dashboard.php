<?php 
session_start();
include '../includes/config.php';
include '../includes/functions.php';

// Redirection si l'utilisateur n'est pas connecté
if (!$_SESSION['user']['matricule']) {
    header("Location: login.php");
    exit();
}

// Traitement de l'annulation de réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['annuler_reservation'])) {
    $id_reservation = $_POST['id_reservation'];

    // Sécurité : vérifier que la réservation appartient bien à l'étudiant connecté
    $stmtCheck = $db->prepare("SELECT * FROM reservation WHERE id_reser = ? AND matricule_etudiant = ?");
    $stmtCheck->execute([$id_reservation, $_SESSION['user']['matricule']]);
    $reservationToDelete = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    if ($reservationToDelete) {
        $stmtDelete = $db->prepare("DELETE FROM reservation WHERE id_reser = ?");
        $stmtDelete->execute([$id_reservation]);
        header("Location: index.php");
        exit();
    }
}

// Récupération des infos étudiant et réservation
$student = get_student_info($db, $_SESSION['user']['matricule']);
$stmt = $db->prepare("SELECT * FROM reservation WHERE matricule_etudiant = ?");
$stmt->execute([$_SESSION['user']['matricule']]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Étudiant</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --danger-color: #ff3333;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('../img/img2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: var(--light-color);
            min-height: 100vh;
        }
        .container { max-width: 1200px; margin: 0 auto; padding: 2rem; }
        header { text-align: center; margin-bottom: 3rem; position: relative; }
        h1 {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, var(--accent-color), var(--primary-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        .welcome-text { font-size: 1.1rem; opacity: 0.9; }
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        .card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: var(--shadow);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: var(--transition);
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        .card-header i { font-size: 1.5rem; margin-right: 1rem; color: var(--accent-color); }
        .card-header h2 { font-size: 1.5rem; font-weight: 600; }
        .info-item { display: flex; margin-bottom: 1rem; align-items: flex-start; }
        .info-label { font-weight: 600; min-width: 120px; opacity: 0.8; }
        .info-value { flex: 1; }
        .btn-group {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            gap: 0.5rem;
        }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--secondary-color); transform: translateY(-2px); }
        .btn-danger { background-color: var(--danger-color); color: white; }
        .btn-danger:hover { background-color: #cc0000; transform: translateY(-2px); }
        .no-reservation { padding: 1.5rem 0; text-align: center; }
        .status-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }
        .status-active { background-color: rgba(75, 181, 67, 0.2); color: var(--success-color); }
        @media (max-width: 768px) {
            .container { padding: 1.5rem; }
            .dashboard-grid { grid-template-columns: 1fr; }
            h1 { font-size: 2rem; }
        }
    </style>
</head>
<body>
<main class="container">
    <header>
        <h1>Tableau de Bord</h1>
        <p class="welcome-text">Bienvenue, <?php echo htmlspecialchars($student['prenom']); ?> <?php echo htmlspecialchars($student['nom']); ?></p>
    </header>

    <div class="dashboard-grid">
        <!-- Carte Profil -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-user-circle"></i>
                <h2>Votre Profil</h2>
            </div>

            <div class="info-item">
                <span class="info-label">Nom complet:</span>
                <span class="info-value"><?php echo htmlspecialchars($student['prenom'] . ' ' . $student['nom']); ?></span>
            </div>

            <div class="info-item">
                <span class="info-label">Matricule:</span>
                <span class="info-value"><?php echo htmlspecialchars($_SESSION['user']['matricule']); ?></span>
            </div>

            <div class="info-item">
                <span class="info-label">Email:</span>
                <span class="info-value"><?php echo htmlspecialchars($student['email']); ?></span>
            </div>

            <div class="info-item">
                <span class="info-label">Téléphone:</span>
                <span class="info-value"><?php echo htmlspecialchars($student['tel']); ?></span>
            </div>
        </div>

        <!-- Carte Réservation -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-bed"></i>
                <h2>Votre Réservation</h2>
            </div>

            <?php if ($reservation): ?>
                <?php 
                    $stmt = $db->prepare("SELECT * FROM chambre WHERE numero = ?");
                    $stmt->execute([$reservation['numero_chambre']]);
                    $chambre = $stmt->fetch(PDO::FETCH_ASSOC);
                ?>

                <div class="info-item">
                    <span class="info-label">Chambre:</span>
                    <span class="info-value">
                        N°<?php echo htmlspecialchars($chambre['numero']); ?> 
                        (<?php echo htmlspecialchars($chambre['type']); ?>)
                        <span class="status-badge status-active">Active</span>
                    </span>
                </div>

                <div class="info-item">
                    <span class="info-label">Date:</span>
                    <span class="info-value"><?php echo date('d/m/Y à H:i', strtotime($reservation['date_reservation'])); ?></span>
                </div>

                <div class="info-item">
                    <span class="info-label">Paiement:</span>
                    <span class="info-value"><?php echo htmlspecialchars($reservation['type_payement']); ?></span>
                </div>

                <div class="btn-group">
                    <a href="details_chambre.php?numero=<?php echo $chambre['numero']; ?>" class="btn btn-primary">
                        <i class="fas fa-info-circle"></i> Détails
                    </a>
                    <form method="post" onsubmit="return confirm('Voulez-vous vraiment annuler votre réservation ?');">
                        <input type="hidden" name="id_reservation" value="<?php echo $reservation['id_reser']; ?>">
                        <button type="submit" name="annuler_reservation" class="btn btn-danger">
                            <i class="fas fa-times"></i> Annuler
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <div class="no-reservation">
                    <p>Vous n'avez actuellement aucune réservation.</p>
                    <a href="chambres.php" class="btn btn-primary" style="margin-top: 1.5rem;">
                        <i class="fas fa-search"></i> Trouver une chambre
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>
</body>
</html>
