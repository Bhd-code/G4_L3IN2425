<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        die('Erreur de sécurité CSRF');
    }

    try {
        $db->beginTransaction();

        // 1. Création réservation
        $stmt = $db->prepare("INSERT INTO reservation (type_payement, matricule_etudiant, numero_chambre) 
                             VALUES (?, ?, ?)");
        $stmt->execute([
            $reservation['type_paiement'],
            $_SESSION['matricule'],
            $numero_chambre
        ]);
        $reservation_id = $db->lastInsertId(); // ID utilisé plus tard

        // 2. Mise à jour disponibilité chambre
        $stmt = $db->prepare("UPDATE chambre SET disponibilite = 'non' WHERE numero = ?");
        $stmt->execute([$numero_chambre]);

        // 3. Création paiement
        $stmt = $db->prepare("INSERT INTO paiements (montant, methode, reservation_id, statut) 
                             VALUES (?, ?, ?, 'complet')");
        $stmt->execute([
            20.00,
            $reservation['type_paiement'],
            $reservation_id
        ]);

        $db->commit();

        // Envoi d'email de confirmation
        $etudiant = get_student_info($db, $_SESSION['matricule']);
        $subject = "Confirmation de votre réservation #$reservation_id";
        $body = "
            <html><body>
                <h2>Confirmation de réservation</h2>
                <p>Bonjour {$etudiant['prenom']},</p>
                <p>Votre réservation a bien été enregistrée :</p>
                <ul>
                    <li><strong>Chambre:</strong> N°{$numero_chambre} ({$chambre['type']})</li>
                    <li><strong>Prix total:</strong> {$chambre['prix']}$</li>
                    <li><strong>Caution payée:</strong> 20$</li>
                    <li><strong>Méthode de paiement:</strong> {$reservation['type_paiement']}</li>
                </ul>
                <p>Vous pouvez suivre votre réservation depuis votre <a href='" . SITE_URL . "/client/dashboard.php'>tableau de bord</a>.</p>
                <p>Cordialement,<br>L'équipe de la Cité Universitaire</p>
            </body></html>
        ";
        if (!send_confirmation_email($etudiant['email'], $subject, $body)) {
            error_log("Échec envoi email à " . $etudiant['email']);
        }

        unset($_SESSION['reservation_temp']);

        $_SESSION['success'] = "Réservation confirmée! Un email vous a été envoyé.";
        header("Location: confirmation.php?id=$reservation_id");
        exit();

    } catch (PDOException $e) {
        $db->rollBack();
        $_SESSION['error'] = "Erreur lors du paiement: " . $e->getMessage();
        header("Location: paiement.php");
        exit();
    }
}


// Récupération infos chambre
$stmt = $db->prepare("SELECT * FROM chambre WHERE numero = ?");
$stmt->execute([$numero_chambre]);
$chambre = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    <title>Paiement - Cité Universitaire</title>
    <style>
        .payment-method {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .payment-method:hover {
            border-color: #0d6efd;
            background-color: #f8f9fa;
        }
        .payment-method.active {
            border-color: #0d6efd;
            background-color: #e7f1ff;
        }
    </style>
</head>
<body>
    <main class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h3 class="mb-0"><i class="fas fa-credit-card me-2"></i> Paiement de la caution</h3>
                    </div>
                    
                    <div class="card-body">
                        <div class="alert alert-info">
                            <h5 class="alert-heading">Résumé de la réservation</h5>
                            <hr>
                            <p class="mb-1"><strong>Chambre:</strong> N°<?= $chambre['numero'] ?> (<?= ucfirst($chambre['type']) ?>)</p>
                            <p class="mb-1"><strong>Prix total:</strong> <?= $chambre['prix'] ?>$</p>
                            <p class="mb-0"><strong>Caution à payer:</strong> <span class="text-success">20$</span></p>
                        </div>
                        
                        <form method="post">
                            <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                            
                            <h4 class="mb-3">Méthode de paiement</h4>
                            
                            <?php if ($reservation['type_paiement'] === 'Carte'): ?>
                                <div class="payment-method active">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="payment_type" id="card" value="card" checked>
                                        <label class="form-check-label fw-bold" for="card">
                                            <i class="far fa-credit-card me-2"></i> Carte bancaire
                                        </label>
                                    </div>
                                    
                                    <div class="mt-3">
                                        <div class="row g-3">
                                            <div class="col-md-12">
                                                <label for="card_number" class="form-label">Numéro de carte</label>
                                                <input type="text" class="form-control" id="card_number" placeholder="1234 5678 9012 3456" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="expiry" class="form-label">Date expiration</label>
                                                <input type="text" class="form-control" id="expiry" placeholder="MM/AA" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="cvv" class="form-label">CVV</label>
                                                <input type="text" class="form-control" id="cvv" placeholder="123" required>
                                            </div>
                                            <div class="col-md-12">
                                                <label for="card_name" class="form-label">Nom sur la carte</label>
                                                <input type="text" class="form-control" id="card_name" placeholder="Nom Prénom" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            <?php elseif ($reservation['type_paiement'] === 'Mobile Money'): ?>
                                <div class="payment-method active">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="payment_type" id="mobile" value="mobile" checked>
                                        <label class="form-check-label fw-bold" for="mobile">
                                            <i class="fas fa-mobile-alt me-2"></i> Mobile Money
                                        </label>
                                    </div>
                                    
                                    <div class="mt-3">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label for="mobile_operator" class="form-label">Opérateur</label>
                                                <select class="form-select" id="mobile_operator" required>
                                                    <option value="">Choisissez...</option>
                                                    <option value="MTN">MTN</option>
                                                    <option value="Orange">Orange</option>
                                                    <option value="Moov">Moov</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="mobile_number" class="form-label">Numéro</label>
                                                <input type="tel" class="form-control" id="mobile_number" placeholder="Ex: 0551234567" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            <?php else: ?>
                                <div class="payment-method active">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="payment_type" id="cash" value="cash" checked>
                                        <label class="form-check-label fw-bold" for="cash">
                                            <i class="fas fa-money-bill-wave me-2"></i> Paiement sur place
                                        </label>
                                    </div>
                                    
                                    <div class="mt-3 alert alert-warning">
                                        <p class="mb-0">Vous paierez la caution directement à l'administration de la cité universitaire lors de votre arrivée.</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="fas fa-check-circle me-2"></i> Confirmer le paiement
                                </button>
                                <a href="reservation.php?numero=<?= $numero_chambre ?>" class="btn btn-outline-secondary">
                                    <i class="fas fa-arrow-left me-2"></i> Retour
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    
    <script>
        // Validation des formulaires de paiement
        document.querySelector('form').addEventListener('submit', function(e) {
            const paymentType = document.querySelector('input[name="payment_type"]:checked').value;
            let valid = true;
            
            if (paymentType === 'card') {
                const cardNumber = document.getElementById('card_number').value;
                const expiry = document.getElementById('expiry').value;
                const cvv = document.getElementById('cvv').value;
                
                if (!/^\d{16}$/.test(cardNumber)) {
                    alert('Numéro de carte invalide (16 chiffres requis)');
                    valid = false;
                }
                
                if (!/^\d{2}\/\d{2}$/.test(expiry)) {
                    alert('Date expiration invalide (format MM/AA)');
                    valid = false;
                }
                
                if (!/^\d{3}$/.test(cvv)) {
                    alert('CVV invalide (3 chiffres requis)');
                    valid = false;
                }
            }
            else if (paymentType === 'mobile') {
                const mobileNumber = document.getElementById('mobile_number').value;
                if (!/^\d{10}$/.test(mobileNumber)) {
                    alert('Numéro mobile invalide (10 chiffres requis)');
                    valid = false;
                }
            }
            
            if (!valid) {
                e.preventDefault();
            } else {
                // Afficher un loader pendant le traitement
                document.querySelector('button[type="submit"]').innerHTML = 
                    '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Traitement...';
            }
        });
    </script>
</body>
</html>

<<?php 

$db->commit();

// Envoi email de confirmation (AJOUTEZ CE BLOC)
$etudiant = get_student_info($db, $_SESSION['matricule']);
$subject = "Confirmation de votre réservation #" . $db->lastInsertId();
$body = "
    <html>
    <body>
        <h2>Confirmation de réservation</h2>
        <p>Bonjour {$etudiant['prenom']},</p>
        
        <p>Votre réservation a bien été enregistrée :</p>
        <ul>
            <li><strong>Chambre:</strong> N°{$numero_chambre} ({$chambre['type']})</li>
            <li><strong>Prix total:</strong> {$chambre['prix']}$</li>
            <li><strong>Caution payée:</strong> 20$</li>
            <li><strong>Méthode de paiement:</strong> {$reservation['type_paiement']}</li>
        </ul>
        
        <p>Vous pouvez annuler ou modifier votre réservation depuis votre <a href='" . SITE_URL . "/client/dashboard.php'>tableau de bord</a>.</p>
        
        <p>Cordialement,<br>L'équipe de la Cité Universitaire</p>
    </body>
    </html>
";

if (!send_confirmation_email($etudiant['email'], $subject, $body)) {
    error_log("Échec envoi email à " . $etudiant['email']);
}

// Nettoyage et redirection
unset($_SESSION['reservation_temp']);
// ... reste du code existant ...

 ?>