<?php
function process_paypal_payment($email, $amount) {
    // Simulation : vrai appel utiliserait l'API REST PayPal ici
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return true;
    }
    return false;
}
