<?php
// reservation.php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Vérification de l'authentification
if (!isset($_SESSION['user']['matricule'])) {
    redirect_with_message('login.php', 'Veuillez vous connecter pour effectuer une réservation', 'danger');
}

$numero_chambre = filter_input(INPUT_GET, 'numero', FILTER_VALIDATE_INT);
if (!$numero_chambre) {
    redirect_with_message('chambres.php', 'Numéro de chambre invalide', 'danger');
}

// Vérification disponibilité chambre 
$stmt = $db->prepare("SELECT * FROM chambre WHERE numero = ? AND disponibilite = 'oui'");
$stmt->execute([$numero_chambre]);
$chambre = $stmt->fetch();

if (!$chambre) {
    redirect_with_message('chambres.php', 'Chambre non disponible', 'danger');
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($token)) {
        die('Erreur de sécurité CSRF');
    }

    $type_paiement = filter_input(INPUT_POST, 'type_paiement', FILTER_SANITIZE_STRING);
    $types_acceptes = ['paypal', 'virement'];

    if (!in_array($type_paiement, $types_acceptes)) {
        redirect_with_message("reservation.php?numero=$numero_chambre", 'Mode de paiement invalide', 'danger');
    }

    $errors = [];
    $payment_data = [];

    if ($type_paiement === 'paypal') {
        $email_paypal = filter_input(INPUT_POST, 'email_paypal', FILTER_VALIDATE_EMAIL);
        if (!$email_paypal) {
            $errors[] = 'Adresse PayPal invalide';
        }
        $payment_data = ['email_paypal' => $email_paypal];
    }

    if ($type_paiement === 'virement') {
        $reference_virement = trim($_POST['reference_virement'] ?? '');
        if (strlen($reference_virement) < 5) {
            $errors[] = 'Référence du virement invalide (au moins 5 caractères)';
        }
        $payment_data = ['reference_virement' => $reference_virement];
    }

    if (!empty($errors)) {
        $_SESSION['form_errors'] = $errors;
        header("Location: reservation.php?numero=$numero_chambre");
        exit;
    }

    // Insertion dans la base de données
    $stmt = $db->prepare("INSERT INTO reservation (matricule_etudiant, numero_chambre, type_payement, date_reservation) VALUES (?, ?, ?, NOW())");
    $stmt->execute([
        $_SESSION['user']['matricule'],
        $numero_chambre,
        $type_paiement
    ]);

    // Marquer la chambre comme non disponible
    $stmt = $db->prepare("UPDATE chambre SET disponibilite = 'non' WHERE numero = ?");
    $stmt->execute([$numero_chambre]);

    // Redirection vers le tableau de bord
    redirect_with_message('dashboard.php', 'Réservation effectuée avec succès !', 'success');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réservation - Chambre <?= htmlspecialchars($chambre['numero']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<main class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h2 class="mb-4">Réservation Chambre <?= htmlspecialchars($chambre['numero']) ?></h2>

            <?php if (!empty($_SESSION['form_errors'])): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($_SESSION['form_errors'] as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php unset($_SESSION['form_errors']); ?>
            <?php endif; ?>

            <div class="card shadow">
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">

                        <div class="mb-3">
                            <label class="form-label">Type de chambre</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars(ucfirst($chambre['type'])) ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Prix</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($chambre['prix']) ?>$" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Caution à payer</label>
                            <input type="text" class="form-control" value="20$" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="type_paiement" class="form-label">Méthode de paiement *</label>
                            <select class="form-select" id="type_paiement" name="type_paiement" required>
                                <option value="">Choisissez...</option>
                                <option value="paypal">PayPal</option>
                                <option value="virement">Virement bancaire</option>
                            </select>
                        </div>

                        <div id="paypal_details" class="mb-3 d-none">
                            <label for="email_paypal" class="form-label">Adresse PayPal *</label>
                            <input type="email" class="form-control" name="email_paypal" id="email_paypal" placeholder="exemple@paypal.com">
                        </div>

                        <div id="virement_details" class="mb-3 d-none">
                            <label for="reference_virement" class="form-label">Référence du virement *</label>
                            <input type="text" class="form-control" name="reference_virement" id="reference_virement" placeholder="Réf. du virement bancaire">
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-arrow-right"></i> Procéder au paiement
                            </button>
                            <a href="details_chambre.php?numero=<?= $chambre['numero'] ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left"></i> Retour
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('type_paiement').addEventListener('change', function () {
        const paypalDiv = document.getElementById('paypal_details');
        const virementDiv = document.getElementById('virement_details');

        paypalDiv.classList.add('d-none');
        virementDiv.classList.add('d-none');

        if (this.value === 'paypal') {
            paypalDiv.classList.remove('d-none');
        } else if (this.value === 'virement') {
            virementDiv.classList.remove('d-none');
        }
    });
</script>
</body>
</html>
