<?php
session_start(); // Démarre la session

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fonction de vérification de connexion
function is_logged_in() {
    return isset($_SESSION['user']['matricule']);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réservation Cité Universitaire</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --danger-color: #ff3333;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: var(--light-color);
            background: linear-gradient(rgba(0, 0, 0, 0.65), rgba(0, 0, 0, 0.65)), url('../img/img1.jpg') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            line-height: 1.6;
        }

        header {
            background: rgba(44, 62, 80, 0.85);
            backdrop-filter: blur(8px);
            padding: 1.2rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.2);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 1.5rem 0;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .logo i {
            font-size: 1.8rem;
            color: var(--accent-color);
        }

        .logo h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 0;
            background: linear-gradient(to right, var(--accent-color), var(--primary-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        nav {
            display: flex;
            gap: 0.8rem;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.7rem 1.5rem;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            font-size: 0.95rem;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--secondary-color);
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(63, 55, 201, 0.3);
        }

        .btn-secondary {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .btn-secondary:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-3px);
        }

        .hero {
            text-align: center;
            padding: 5rem 2rem;
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            margin: 2rem 0;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: var(--shadow);
        }

        .hero h2 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            font-weight: 700;
            background: linear-gradient(to right, #fff, var(--accent-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .hero p {
            font-size: 1.2rem;
            opacity: 0.9;
            max-width: 700px;
            margin: 0 auto;
        }

        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin: 3rem 0;
        }

        .feature {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(10px);
            padding: 2rem;
            border-radius: 12px;
            text-align: center;
            transition: var(--transition);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .feature:hover {
            transform: translateY(-8px);
            background: rgba(255, 255, 255, 0.12);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }

        .feature i {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
            color: var(--accent-color);
        }

        .feature h3 {
            font-size: 1.3rem;
            margin-bottom: 1rem;
            color: white;
        }

        .feature p {
            opacity: 0.85;
            font-size: 0.95rem;
        }

        footer {
            background: rgba(44, 62, 80, 0.85);
            backdrop-filter: blur(8px);
            padding: 1.5rem 0;
            margin-top: 3rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        footer p {
            text-align: center;
            opacity: 0.8;
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
            }
            
            .hero {
                padding: 3rem 1.5rem;
            }
            
            .hero h2 {
                font-size: 2rem;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .hero, .feature {
            animation: fadeIn 0.6s ease-out forwards;
        }

        .feature:nth-child(1) { animation-delay: 0.2s; }
        .feature:nth-child(2) { animation-delay: 0.4s; }
        .feature:nth-child(3) { animation-delay: 0.6s; }
    </style>
</head>
<body>

    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <i class="fas fa-home"></i>
                    <h1>Réservation Cité U</h1>
                </div>
                <nav>
                    <?php if (is_logged_in()): ?>
                        <a href="dashboard.php" class="btn btn-primary">
                            <i class="fas fa-tachometer-alt"></i> Tableau de bord
                        </a>
                        <a href="chambres.php" class="btn btn-primary">
                            <i class="fas fa-bed"></i> Réserver
                        </a>
                        <a href="logout.php" class="btn btn-secondary">
                            <i class="fas fa-sign-out-alt"></i> Déconnexion
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary">
                            <i class="fas fa-sign-in-alt"></i> Connexion
                        </a>
                        <a href="register.php" class="btn btn-secondary">
                            <i class="fas fa-user-plus"></i> Inscription
                        </a>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </header>

    <main class="container">
        <section class="hero">
            <h2>Bienvenue dans la Cité Universitaire</h2>
            <p>Découvrez un hébergement étudiant moderne avec des chambres confortables et tous les services nécessaires pour votre réussite académique</p>
        </section>

        <section class="features">
            <div class="feature">
                <i class="fas fa-bed"></i>
                <h3>Chambres Confortables</h3>
                <p>Espace personnalisé avec lit, bureau et rangements, wifi haut débit inclus</p>
            </div>
            <div class="feature">
                <i class="fas fa-calendar-check"></i>
                <h3>Réservation Simple</h3>
                <p>Processus 100% en ligne avec confirmation immédiate de votre réservation</p>
            </div>
            <div class="feature">
                <i class="fas fa-lock"></i>
                <h3>Paiement Sécurisé</h3>
                <p>Transactions cryptées avec plusieurs options de paiement disponibles</p>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; <?= date('Y') ?> Cité Universitaire - Tous droits réservés</p>
        </div>
    </footer>

</body>
</html>