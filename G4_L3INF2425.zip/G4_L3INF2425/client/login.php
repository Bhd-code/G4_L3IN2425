
<?php 
session_start(); // Démarrage de la session
include '../includes/config.php';

// Redirection si l'utilisateur est déjà connecté
if (isset($_SESSION['user']['matricue'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $matricule = secure_input($_POST['matricule']);
    $password = secure_input($_POST['password']);
    
    $stmt = $db->prepare("SELECT * FROM etudiant WHERE matricule = ?");
    $stmt->execute([$matricule]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
       $_SESSION['user']=[
            "matricule" => $matricule,
            "nom" => $nom,
            "prenom" => $prenom,
            "sexe" =>$sexe,
            "email" =>$email 
        ];
        header("Location: index.php");
        exit();
    } else {
        $error = "Matricule ou mot de passe incorrect";
    }
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <h2>Connexion</h2>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        
        <form  method="post">
            <div class="form-group">
                <label for="matricule">Matricule</label>
                <input type="text" id="matricule" name="matricule" required>
            </div>
            
            <div class="form-group">
                <label for="password">Mot de passe</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn">Se Connecter</button>
        </form>
        
        <p>vous avez un compte? <a href="register.php">S'inscrire</a></p>
    </div>
</body>
</html>