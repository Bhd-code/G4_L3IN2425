-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 08 juin 2025 à 21:15
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `reservation_cite_universitaire`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `nom` varchar(10) NOT NULL,
  `matricule` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`nom`, `matricule`, `email`, `password`) VALUES
('BRAHIM', '22B069FS', 'a@gmail.com', 'aaaa');

-- --------------------------------------------------------

--
-- Structure de la table `batiment`
--

CREATE TABLE `batiment` (
  `id_bat` int(11) NOT NULL,
  `nbre_ch` int(11) NOT NULL,
  `section` enum('fille','garçon') NOT NULL,
  `statut` enum('étudiant','enseignant') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `batiment`
--

INSERT INTO `batiment` (`id_bat`, `nbre_ch`, `section`, `statut`) VALUES
(1, 20, '', 'étudiant'),
(2, 20, 'garçon', 'étudiant'),
(3, 46, 'fille', ''),
(4, 10, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `chambre`
--

CREATE TABLE `chambre` (
  `numero` int(11) NOT NULL,
  `type` enum('studio','simple') NOT NULL,
  `disponibilite` enum('oui','non') NOT NULL DEFAULT 'oui',
  `prix` decimal(10,2) NOT NULL,
  `id_bat` int(11) DEFAULT NULL,
  `numero_ch` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `chambre`
--

INSERT INTO `chambre` (`numero`, `type`, `disponibilite`, `prix`, `id_bat`, `numero_ch`, `image`) VALUES
(1, 'studio', 'non', 290.00, 2, 0, NULL),
(2, 'studio', 'oui', 3436.00, 2, 0, NULL),
(3, 'studio', 'non', 25000.00, 1, 1, NULL),
(4, 'simple', 'oui', 25000.00, 1, 1, NULL),
(5, '', 'non', 100200.00, 1, 1, NULL),
(8, 'studio', 'oui', 21990.00, 2, 5, NULL),
(10, 'studio', 'oui', 21990.00, 2, 11, 'uploads/chambres/chambre_6845dcd922c506.79231022.jpg'),
(11, 'simple', 'oui', 1500.00, 2, 15, 'uploads/chambres/chambre_6845df4b90f245.22263521.jpg'),
(12, 'studio', 'non', 210.00, 1, 14, 'uploads/chambres/chambre_6845e0fc3020e6.06152581.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

CREATE TABLE `commentaire` (
  `id_com` int(11) NOT NULL,
  `message` text NOT NULL,
  `date_envoie` datetime DEFAULT NULL,
  `id_equi` int(11) DEFAULT NULL,
  `matricule_etudiant` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déclencheurs `commentaire`
--
DELIMITER $$
CREATE TRIGGER `before_insert_commentaire` BEFORE INSERT ON `commentaire` FOR EACH ROW BEGIN
    SET NEW.date_envoie = NOW();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `equipement`
--

CREATE TABLE `equipement` (
  `id_equi` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `numero_chambre` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `equipement`
--

INSERT INTO `equipement` (`id_equi`, `nom`, `description`, `image`, `numero_chambre`) VALUES
(1, 'TABLE', 'PERMET DE SERVIR COMME BUREAU D\'ETUDE', NULL, 1),
(3, 'chaise', 'idkjeijla\r\nfoiehfqsklfns', '6844a3a2f31d4_Image1.png', 1),
(4, 'chaise', 'voici votre chaise. elle est trop confortablesssssss\r\nssssssssssssssssssssssssssssss', '6844ac7025929_gettyimages-157588637-170667a.jpg', 5),
(5, 'chaise', 'voici votre chaise. elle est trop confortable', '6844ada223f89_gettyimages-157588637-170667a.jpg', 2);

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `matricule` varchar(20) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `tel_parent` varchar(20) DEFAULT NULL,
  `adress_parent` text DEFAULT NULL,
  `sexe` enum('Homme','Femme') DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`matricule`, `nom`, `prenom`, `email`, `tel`, `tel_parent`, `adress_parent`, `sexe`, `password`) VALUES
('123', 'AZE', 'QSD', 'aze@gmail.com', '6740031', NULL, NULL, '', '$2y$10$XLmE1MSEtlGzPa257KHxkOxqHO5FWFYnObhyvIZxlX8AwMZFKb4kG'),
('222B069FS', 'brahim', 'djouma', 'djouma@gmail.com', '6372726', '52282', 'kqueh', 'Homme', 'BRA'),
('22A176FS', 'oumar', 'tchou', 'oumar@gmail.com', '5555544', NULL, NULL, '', '$2y$10$2q3roWpWQL8wnkZRHLygVeq60fA12w/d4wrnnuw00IbzS7F/0pFuC'),
('22A382FS', 'MAHASSAB', 'ABDERAHIM', 'mahassab@gmail.com', '4853452363', NULL, NULL, '', '$2y$10$bcz1K1/Vd7a9nYP4QiAtTOsYlhhuRqO/iJy0f1NiJcbdxejQaqgvS'),
('25B069FS', 'MHT', 'ALI', 'ali@gmail.com', '6847339', NULL, NULL, 'Homme', '$2y$10$BL9wLScRcpDC5ExtxJW5gusdSozn/Bt9x6PT9UCIEuz18fSm9Zmna'),
('2B069FS', 'brahim', 'djouma', 'djoum@gmail.com', '67678', NULL, NULL, '', '$2y$10$MuIHDUeANPvxYs/xTYzgN.4YGQYk3SBSAhAJ/gMGrcEnlCh305K2.'),
('30B069FS', 'HSSN', 'ALI', 'hssn@gmail.com', '55740031', NULL, NULL, 'Homme', '$2y$10$368k0sTZp.HPIOakp96i7uvCqu15B2nEUee9Myme2/3ljY4c55a5W');

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

CREATE TABLE `reservation` (
  `id_reser` int(11) NOT NULL,
  `date_reservation` datetime DEFAULT current_timestamp(),
  `type_payement` enum('Espèce','Carte','Mobile Money') NOT NULL,
  `matricule_etudiant` varchar(20) DEFAULT NULL,
  `numero_chambre` int(11) DEFAULT NULL,
  `notification_envoyee` tinyint(1) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `reservation`
--

INSERT INTO `reservation` (`id_reser`, `date_reservation`, `type_payement`, `matricule_etudiant`, `numero_chambre`, `notification_envoyee`, `email`) VALUES
(3, '2025-06-19 00:00:00', 'Espèce', '2B069FS', 2, 0, 'petitfilsdedjouma@gmail.com'),
(20, '2025-05-01 11:33:08', 'Espèce', '25B069FS', 1, 0, 'adoumkally989@gmail.com'),
(21, '2025-05-26 00:00:00', 'Espèce', '22A176FS', 5, 0, ''),
(22, '2025-05-26 00:00:00', 'Espèce', '222B069FS', 3, 0, ''),
(26, '2025-06-08 21:14:38', '', '123', 12, 0, '');

--
-- Déclencheurs `reservation`
--
DELIMITER $$
CREATE TRIGGER `after_delete_reservation` AFTER DELETE ON `reservation` FOR EACH ROW BEGIN
    UPDATE chambre SET disponibilite = 'oui' WHERE numero = OLD.numero_chambre;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_reservation` AFTER INSERT ON `reservation` FOR EACH ROW BEGIN
    UPDATE chambre SET disponibilite = 'non' WHERE numero = NEW.numero_chambre;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_insert_reservation` BEFORE INSERT ON `reservation` FOR EACH ROW BEGIN
    DECLARE existing_reservations INT;
    
    SELECT COUNT(*) INTO existing_reservations 
    FROM reservation 
    WHERE matricule_etudiant = NEW.matricule_etudiant;
    
    IF existing_reservations > 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Cet étudiant a déjà une réservation active';
    END IF;
END
$$
DELIMITER ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`matricule`);

--
-- Index pour la table `batiment`
--
ALTER TABLE `batiment`
  ADD PRIMARY KEY (`id_bat`);

--
-- Index pour la table `chambre`
--
ALTER TABLE `chambre`
  ADD PRIMARY KEY (`numero`),
  ADD KEY `id_bat` (`id_bat`);

--
-- Index pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD PRIMARY KEY (`id_com`),
  ADD KEY `id_equi` (`id_equi`),
  ADD KEY `matricule_etudiant` (`matricule_etudiant`);

--
-- Index pour la table `equipement`
--
ALTER TABLE `equipement`
  ADD PRIMARY KEY (`id_equi`),
  ADD KEY `numero_chambre` (`numero_chambre`);

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`matricule`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id_reser`),
  ADD KEY `matricule_etudiant` (`matricule_etudiant`),
  ADD KEY `numero_chambre` (`numero_chambre`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `batiment`
--
ALTER TABLE `batiment`
  MODIFY `id_bat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `chambre`
--
ALTER TABLE `chambre`
  MODIFY `numero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `commentaire`
--
ALTER TABLE `commentaire`
  MODIFY `id_com` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `equipement`
--
ALTER TABLE `equipement`
  MODIFY `id_equi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id_reser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `chambre`
--
ALTER TABLE `chambre`
  ADD CONSTRAINT `chambre_ibfk_1` FOREIGN KEY (`id_bat`) REFERENCES `batiment` (`id_bat`) ON DELETE CASCADE;

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `commentaire_ibfk_1` FOREIGN KEY (`id_equi`) REFERENCES `equipement` (`id_equi`) ON DELETE CASCADE,
  ADD CONSTRAINT `commentaire_ibfk_2` FOREIGN KEY (`matricule_etudiant`) REFERENCES `etudiant` (`matricule`) ON DELETE CASCADE;

--
-- Contraintes pour la table `equipement`
--
ALTER TABLE `equipement`
  ADD CONSTRAINT `equipement_ibfk_1` FOREIGN KEY (`numero_chambre`) REFERENCES `chambre` (`numero`) ON DELETE CASCADE;

--
-- Contraintes pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`matricule_etudiant`) REFERENCES `etudiant` (`matricule`) ON DELETE CASCADE,
  ADD CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`numero_chambre`) REFERENCES `chambre` (`numero`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
