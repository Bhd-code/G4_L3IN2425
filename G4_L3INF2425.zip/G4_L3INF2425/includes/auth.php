<?php

session_start();
var_dump($_SESSION);
exit;

require_once 'config.php';
require_once 'functions.php';

// Définir un délai d'inactivité max (optionnel)
$timeout_duration = 1800; // 30 minutes

// Vérification de la connexion
if (!is_logged_in()) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    redirect_with_message('login.php', 'Veuillez vous connecter pour accéder à cette page.', 'danger');
}

// Timeout de session si inactif trop longtemps
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    session_unset();
    session_destroy();
    redirect_with_message('login.php', 'Session expirée. Veuillez vous reconnecter.', 'danger');
}

// Vérifier le rôle (si $required_role est défini)
if (isset($required_role)) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $required_role) {
        redirect_with_message('dashboard.php', 'Accès non autorisé.', 'danger');
    }
}

// Récupérer les infos de l'utilisateur connecté
$current_user = get_student_info($db, $_SESSION['matricule']);
if (!$current_user) {
    session_destroy();
    redirect_with_message('login.php', 'Votre compte n\'existe plus.', 'danger');
}

// Mise à jour de la dernière activité
$_SESSION['last_activity'] = time();
?>
