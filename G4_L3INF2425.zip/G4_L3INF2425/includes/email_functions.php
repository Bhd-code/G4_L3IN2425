<?php

/**
 * Prépare un modèle d'email avec les données dynamiques fournies.
 *
 * @param string $template_name Nom du modèle à utiliser
 * @param array $replacements Clés => valeurs à remplacer dans le template
 * @return string Contenu final de l'email
 */
function prepare_email_template($template_name, $replacements) {
    // Liste des modèles disponibles
    $templates = [
        'reservation_confirmation' => "
            <h2>Confirmation de réservation</h2>
            <p>Bonjour {{prenom}},</p>
            <p>{{contenu}}</p>
            <p>Cordialement,<br>{{signature}}</p>
        "
    ];

    // Récupération du template
    $template = $templates[$template_name] ?? '';
    
    // Remplacement des variables {{clé}} par leur valeur
    foreach ($replacements as $key => $value) {
        $template = str_replace("{{{$key}}}", htmlspecialchars($value), $template);
    }

    return $template;
}

/**
 * Envoie un email basé sur un template HTML défini.
 *
 * @param string $to Email du destinataire
 * @param string $subject Sujet de l'email
 * @param string $template_name Nom du template utilisé
 * @param array $data Données à injecter dans le template
 * @return bool Succès ou échec de l'envoi
 */
function send_email_with_template($to, $subject, $template_name, $data) {
    // Ajoute une signature par défaut
    $body = prepare_email_template($template_name, array_merge([
        'signature' => 'Équipe Cité Universitaire'
    ], $data));

    return send_confirmation_email($to, $subject, $body);
}
