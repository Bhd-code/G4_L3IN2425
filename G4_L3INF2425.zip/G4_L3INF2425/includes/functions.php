<?php
// S'assurer que la session est démarrée
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifie si l'utilisateur est connecté
function is_logged_in() {
    return isset($_SESSION['etudiant']['matricule']);
}



// Redirige l'utilisateur vers la page de connexion s'il n'est pas connecté
function redirect_if_not_logged_in() {
    if (!is_logged_in()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        redirect_with_message('../client/login.php', 'Veuillez vous connecter pour accéder à cette page', 'danger');
    }
}

// Retourne les infos d'un étudiant à partir de son matricule
function get_student_info($db, $matricule) {
    $stmt = $db->prepare("SELECT * FROM etudiant WHERE matricule = ?");
    $stmt->execute([$matricule]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Valide un email
function is_valid_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Redirige vers une URL avec un message flash
function redirect_with_message($url, $message, $type = 'success') {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
    header("Location: $url");
    exit();
}

// Hache un mot de passe de manière sécurisée
function hash_password($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

// Vérifie si un mot de passe correspond au hash
function verify_password($password, $hash) {
    return password_verify($password, $hash);
}

// Affiche un message flash si présent
function display_flash_message() {
    if (!empty($_SESSION['flash_message'])) {
        $type = $_SESSION['flash_type'] ?? 'info';
        echo "<div class='alert alert-$type alert-dismissible fade show' role='alert'>";
        echo htmlspecialchars($_SESSION['flash_message']);
        echo "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>";
        echo "</div>";
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
    }
}
?>
