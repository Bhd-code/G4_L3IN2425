        </main>

    <footer class="bg-dark text-white py-4 mt-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><?php echo SITE_NAME; ?></h5>
                    <p>Système de gestion des réservations pour la cité universitaire.</p>
                </div>
                <div class="col-md-4">
                    <h5>Liens rapides</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo SITE_URL; ?>" class="text-white">Accueil</a></li>
                        <?php if (is_logged_in()): ?>
                            <li><a href="<?php echo SITE_URL; ?>/client/dashboard.php" class="text-white">Tableau de bord</a></li>
                            <li><a href="<?php echo SITE_URL; ?>/client/chambres.php" class="text-white">Chambres disponibles</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo SITE_URL; ?>/client/login.php" class="text-white">Connexion</a></li>
                            <li><a href="<?php echo SITE_URL; ?>/client/register.php" class="text-white">Inscription</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contact</h5>
                    <address>
                        <i class="fas fa-map-marker-alt"></i> 123 Avenue de l'Université<br>
                        <i class="fas fa-phone"></i> +123 456 7890<br>
                        <i class="fas fa-envelope"></i> contact@cite-universitaire.edu
                    </address>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. Tous droits réservés.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- JS personnalisé -->
    <script src="<?php echo SITE_URL; ?>/assets/js/script.js"></script>
    
    <?php if (defined('ENVIRONMENT') && ENVIRONMENT === 'development'): ?>
        <script>
            console.log('Mode développement activé');
        </script>
    <?php endif; ?>
</body>
</html>